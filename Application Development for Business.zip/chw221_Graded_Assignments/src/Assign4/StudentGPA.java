/*******************************************************************************
 * Project4, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: September 28, 2019
 * 
 * In this program, it prompts the user to input the current GPA and current
 * credits, and then calculate out the projected GPA after the semester by 
 * asking the credits and grade for individual courses. Then inform the user 
 * whether the GPA will go up, down, or remain the same.
*******************************************************************************/
package Assign4;


public class StudentGPA {//begin class
  public static void main(String[] args)
    {
    
    double currentgpa; //current gpa
    double currentcredits;//current credit hours
    int credit1;//credit hour for course 1

    double Sgrade1 ; //4.0 scale grade for course1

    String grade1;//letter grade for course
    double totalcredits = 0;
    double semestergpa;
    double projectedgpacase1;
    int count; //the count for which course
    double semesterquality = 0 ;//quality points for the next semester
    double currentquality;//quality points for current
    double coursequality; //single quality point for one course


    System.out.println("What is your current GPA? (4.0 scale)");
    
    currentgpa=TextIO.getlnDouble();
    
    System.out.println("What is your current credits?");
    
    currentcredits=TextIO.getlnDouble();
    
    currentquality = currentgpa*currentcredits;
    
     for (int n=0;n<5;n++){  
     
     count = n+1;   

     
 
     System.out.println("What is your letter grade for course "+count+"?"); 
   
     grade1 = TextIO.getln();
     grade1 = grade1.toUpperCase();
 
     System.out.println("How many credits?"); 

     credit1 = TextIO.getlnInt();
     
     totalcredits = totalcredits + credit1; 
     while (!grade1.equals("A") && !grade1.equals("A-") && !grade1.equals("B+") && 
                    !grade1.equals("B") && !grade1.equals("B-") && !grade1.equals("C+") && 
                    !grade1.equals("C") && !grade1.equals("C-") && !grade1.equals("D+") && 
                    !grade1.equals("D") && !grade1.equals("F")){
                System.out.println("Please enter a valid Lehigh letter grade.");
                System.out.print("Grade: ");
                grade1 = TextIO.getln();
                grade1 = grade1.toUpperCase();
            }
            
         
         switch (grade1) { //course 1 conditions
          case "A":
              Sgrade1 = 4.0;
              break;
          case "A-":
              Sgrade1 = 3.7;
              break;
          case "B+":Sgrade1 = 3.3;
              break;
          case "B":
              Sgrade1 = 3.0;
              break;
          case "B-":
              Sgrade1 = 2.7;
              break;
          case "C+":
              Sgrade1 = 2.3;
              break;
          case "C":
              Sgrade1 = 2.0;
              break;
          case "C-":
              Sgrade1 = 1.7;
              break;
          case "D+":
              Sgrade1 = 1.3;
              break;
          case "D":
              Sgrade1 = 1.0;
              break;
          default:
              Sgrade1 = 0.0;
              break;
      }
         
        
        coursequality = Sgrade1*credit1; //course quality point calculation
        semesterquality = semesterquality + coursequality; // semester quality points
         
        
                      
     }
     
        semestergpa = semesterquality / totalcredits; //calculate the semester gpa
        projectedgpacase1 = (currentquality+semesterquality)/(currentcredits+totalcredits); //calculate the projected gpa  
        
        
             
        System.out.println("");
        System.out.println("-----------------------------------");
     
     if (currentgpa<semestergpa){ //case which gpa will rise              
        System.out.print("Your projected GPA is ");
        System.out.printf("%4.2f", projectedgpacase1);
        System.out.println("");
        System.out.print("That’s great!Your GPA will rise by ");
        System.out.printf("%4.2f",projectedgpacase1-currentgpa);
        System.out.print(".");
        
        }
        else if (currentgpa > semestergpa){ //case which gpa will decrease
            System.out.print("Your projected GPA is ");
            System.out.printf("%4.2f", projectedgpacase1);
            System.out.println("");
              System.out.print("Your GPA will go down by " );
              System.out.printf("%4.2f",(currentgpa-projectedgpacase1));
              System.out.println(" maybe try studying more.");
        }
        else if (currentgpa == semestergpa){ //case which gpa is the same
            System.out.println("Your projected GPA is " + currentgpa);
            System.out.println("Your GPA will remain the same.");
        }
     
     
    
          
        
          
      
    }   
}//end class
