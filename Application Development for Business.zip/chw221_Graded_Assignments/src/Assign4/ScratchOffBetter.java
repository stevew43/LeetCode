/*******************************************************************************
 * Project4, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: September 28, 2019
 * 
 * A modified version of ScratchOff program. It generates three unique winning 
 * numbers and performs a loop to test whether the user has the same number as 
 * one of the winning numbers. The winning numbers are tracked and calculated at
 * the end of the program. Lastly, it asks the user whether wants to play the 
 * game again.
*******************************************************************************/
package Assign4;


public class ScratchOffBetter { //begin class
    public static void main(String[] args)
    {
       
        
     
     int winamt; //winning amount for a single trial
     int winamt1 = 0; // winning amount for the total
     double number1301; //the first win number from 1-30
     double number1302; //the second win number from 1-30
     double number1303; //the third win number from 1-30
     int N1301; //the first win number 1-30 converted into int
     int N1302; //the second number 1-30 converted into int
     int N1303; //the third number 1-30 converted into int
     double usernum1; //the user's number
     int usernumber1; //the user's number converted into int
     int trial; // the trial for the loop
     char input; //input for playing again
    
     
     do{ //do while loop starts
     System.out.println("Welcome to the scratch off lottery game!");
     System.out.println("");
     System.out.println("Here are the winning numbers that you need to match:");
     

   
        number1301 = Math.random()*30+1;//the win number from 1-30
        number1302 = Math.random()*30+1;//the win number from 1-30
        number1303 = Math.random()*30+1;//the win number from 1-30

        N1301 = (int)number1301; // the win number 1-30 converted into int
        N1302 = (int)number1302; // the win number 1-30 converted into int
        N1303 = (int)number1303; // the win number 1-30 converted into int
        
       
     while(true){
              if(N1301 != N1302 && N1301 != N1303 && N1302!= N1303){  

              System.out.println(N1301+","+N1302+","+N1303);
        
              break;
              }
              
              number1301 = Math.random()*30+1;//the win number from 1-30
              number1302 = Math.random()*30+1;//the win number from 1-30
              number1303 = Math.random()*30+1;//the win number from 1-30
              N1301 = (int)number1301; // the win number 1-30 converted into int
              N1302 = (int)number1302; // the win number 1-30 converted into int
              N1303 = (int)number1303; // the win number 1-30 converted into int    
                
              }
        System.out.println("----------------------------");
        System.out.println("");
        System.out.println("Here are the results:");
        
        
        for (trial=1;trial<=10;trial++){ //for loop starts
        usernum1 = Math.random()*30+1; //user generated number
        usernumber1 = (int)usernum1; // converted into int
        
        if(usernumber1 == N1301 ||usernumber1 ==N1302 || usernumber1==N1303)//win or lose condition
        {
            winamt = usernumber1*usernumber1; //the wining amount in a single trial
            winamt1 = winamt1+ winamt; // the total wining amount
        
        System.out.println("Round "+trial+": "+"You win! The number is "
                +usernumber1+" and you win an amount of $"+winamt+".00");
        
        }
         else   
         System.out.println("Round "+trial+": "+"Sorry, you lost.");  
        
        
        } // for loop ends
     
        System.out.print("\nYou win a total amount of $!");
        System.out.print(winamt1+".00");
        
        System.out.println("");
        System.out.println("\nDo you want to play again? (Type Y for yes, "
                + "N for no)");
        
        input = TextIO.getlnChar(); //get user input for whether to play again
        
        
        while(input != 'Y' ||input!='N'){ // while loop starts
            

           if(input =='Y'||input=='N'){ //test if the user type in Y or N
               break;
           }
            
           else{
           System.out.println("Plase type in Y or N.");
            input = TextIO.getlnChar(); 
            
           }
        } //while loop ends
     
        
     } while (input=='Y'); //do while loop ends
        
     }
    
 
    
     }//end class
   

     

   

