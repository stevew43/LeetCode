/*******************************************************************************
 * Project4, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: September 28, 2019
 * 
 * A user credentials validation program which asks the user to provide username
 * password, date of birth, age, and gender. Each field has a specific format to
 * follow, if the user enters the wrong format, the user will be alerted. If all
 * credentials are valid, it will output all the user information at the end of
 * the program.
 * 
 * Extra credit attempt:
 * Please consider line 251 to 288 for adding a feature which test if user 
 * entered a real age, especially to test whether the user has already passed 
 * birthday. If the user did not have birthday but simply type in the age by 
 * subtracting own birth year from the current year, user will be alerted to 
 * type in the age again.
 * Source:https://beginnersbook.com/2014/01/how-to-get-current-day-month-year
 * -day-of-weekmonthyear-in-java/
*******************************************************************************/
package Assign4;

import java.util.Calendar; //extra credit related: calendar (online source)
import java.util.TimeZone; //extra credit related: timezone (online source)



public class ValidationPractice {//begin class
 public static void main(String[] args)
    {        
        
    String username = null; //username input
    String password = null; //password input
    int length;//username length
    int lengthp;//password length
    int day;//day of dob
    int month;//month of dob
    int year;//year of dob
    int age;//age
    String gender = null;//gender input
    String months = null;
    boolean lengthcon; //password length condition
    boolean symcon = false; //password symbol condition
    boolean capcon = false;  //password cap condition
    boolean numcon = false;  //password num condition
    boolean lengthc = false; //username length condition
    boolean cap = false; //username capital letter condition
    boolean num = false; //username number condition
    boolean alp = false; //username alphabet condition
    boolean monthcon1 = false;
    boolean monthcon2= false;
    boolean monthcon3 = false;
    boolean agever = false; // verify for a reasonable age
    boolean yearver; //extracredit: verify for real age
     //boolean monthver = false;
     //boolean dayver = false;
     
    

System.out.println("What is your username?");
    do { //do while loop starts

         System.out.println("Length must be exactly 8 "
                 + "and can only have upper or");
         System.out.println("lowercase letter, or digit from 0 to 9");        
         username = TextIO.getln(); //get username input
         length = username.length(); //username length
         
         if(length == 8){ //test for username length
             lengthc = true;
        
         for (int n=0; n<8; n++){ //test for username format
             if((username.charAt(n)>='a' && username.charAt (n)<='z')||
                     (username.charAt(n)>='A'&&username.charAt(n)<='Z')||
                     (username.charAt(n)>='0' && username.charAt(n)<='9')){
             cap = true; //cap is met
             num = true; //number is met
             alp = true;} //alphabet is met
             
            else{ //condition when format is not met
                 System.out.println("\nNo special character please:");
                 cap = false; //reset to false
                 num = false;
                 alp = false;
                 
                 username = TextIO.getln();
                 }
         }
         }
         

         if(lengthc==true && cap==true && alp==true && num==true){ //if all conditions are true
             
            break; 
         }
          else { //condition if lenghth is false
             System.out.println("\nWrong username length:");
             lengthc = false;
             cap = false;
             num = false;
             alp = false;
             
         //    username = TextIO.getln();
         }

                  

    }while(lengthc == false || num == false || cap== false || alp == false); //end of do while loop
      
    
  
  System.out.println("");
    
       System.out.println("What is your password?");        
   do {
 
      System.out.println("Length must be 8-12, at least one uppercase letter,");
      System.out.println("at least one number from 0 to 9, and at leaset one");  
      System.out.println("special symbol from !@#$%^*&"); 
         password = TextIO.getln();
         lengthp = password.length(); 

      if (lengthp >=8 && lengthp <=12){ //test for password length
          lengthcon = true;

     
            for (int n=0; n<lengthp; n++){ // start of for loop
                if (password.charAt(n)=='!'||password.charAt(n)=='@'||
                    password.charAt(n)=='#'||password.charAt(n)=='$'||
                    password.charAt(n)=='%'||password.charAt(n)=='^'||
                    password.charAt(n)=='*'||password.charAt(n)=='&')
                    symcon = true;//symbol condition
                         
                if (password.charAt(n)>= 'A' && password.charAt(n)<= 'Z')
                    capcon = true; //uppercase condition


               
                if (password.charAt(n)>= '0' && password.charAt(n)<='9')     
                    numcon = true; //number condition  

          
            } // end of for loop
         }
    
        else{ //when pw length is false
             
              System.out.println("You have the wrong password length:"); 
              lengthcon=false; 
              symcon=false;
              capcon=false;
              numcon=false;                          
           }
        
        if (lengthcon ==true && symcon==true && capcon==true && numcon==true){//all conditions are true
                
              break;  
             }
         
        else {

                System.out.println("You should contain special symbol, "
                        + "uppercase, and number 1-9:");                
                lengthcon=false;//reset
                symcon=false;
                capcon=false;
                numcon=false; 
        } 
   }while(lengthcon==false||symcon == false || capcon ==false || numcon==false); //end of do while loop
            
    
   
   System.out.println("");  
   

   
   

    
    System.out.println("What is your month of birth? (type in number)");
    
     while (true){
        
        month = TextIO.getlnInt();
        
        if (month < 13 && month > 0) //month range
        
            break;
        System.out.println("Your month of birth must be 1-12:");//when out of range
        
    }
     
     do {
         System.out.println("What is your day of birth? ");
         
         day = TextIO.getlnInt();
         if ((month == 1|| month ==3 || month ==5 || month==7||month==8||
                 month ==10 ||month==12)&&(day>=1 && day<=31)){   //test for months of 31 days
             //monthcon1 = true;
             break;
         }
          if  (( month == 4|| month ==6 || month==9||month==11)&&(day>=1 
                  && day<=30)){                                   //test for months of 30 days
             //monthcon2 = true;
             break;
         }
          if (month==2&&(day>=1 && day<=28)){                     //test for Feb
             //monthcon3 =true;
             break;
         }

         
     }while(monthcon1 ==false || monthcon2==false || monthcon3==false);

    
    System.out.println("What is your year of birth?");
    
     while (true){
        
        year = TextIO.getlnInt();
        
        if (year <= 2019 && year >= 1900)//year range
        
            break;
        System.out.println("Your year of birth must be 1900-present:");//when out of range
        
    }
    
     
    System.out.println("");
    
    
    System.out.println("What is your gender? (type in 'male', 'female' "
            + "or 'other)");
    
     while (true){
        
        gender = TextIO.getln();
        gender = gender.toLowerCase();
        if (gender.equals("female") || gender.equals("male")
                ||gender.equals("other")) //gender format
        
            break;
        System.out.println("Your must type in male, female or other:"); //when wrong format
     
    }
    
     
    System.out.println("");
       // ----------------------------------------------------------------extra credit begins----------------------------------------------------------------------------------------  
     Calendar calendar = Calendar.getInstance(TimeZone.getDefault()); //calendar time zone (online source)

      int mm = calendar.get(Calendar.MONTH)+1 ;                       //get the current month   
      int yy = calendar.get(Calendar.YEAR);                          //get the current year  
      int dd = calendar.get(Calendar.DAY_OF_MONTH);                  //get the current month    
      
 System.out.println("dd is " + dd); 
     do{                                                      
     System.out.println("What is your age?");
     
     age = TextIO.getlnInt();
     
     if (age>=0&&age<=130){
         agever =true;
     }
     else{
         agever = false;
         System.out.println("Please enter a valid age (under 130).");
     }       
           
     if ((((yy -year == age)&&(month<mm)&&(day>dd)))||((yy - year ==age)&&   // the five conditions of when age is valid, 
             (month<mm)&&(day<dd))||((yy - year == age +1)&& (month > mm) &&     //conditions include whether year, month, or day is met ( exceed or below or equals current date)
             (day < mm))||((yy - year == age +1)&& (month > mm) && (day > mm))||
             ((yy - year == age)&& (month == mm) && (day == dd))){
         //yearver = true;
         break;
     }
     
     else{    //when the above conditions are not met
         System.out.println("Please type in your real age "
                 + "(count from the date of your birthday)");
         yearver = false;
     }                                    


 }while(agever=false|| yearver == false);  //do while loop end
   // ----------------------------------------------------------------------extra credit ends------------------------------------------------------------------------------------------
                                                              
                                                              
     
     if(month ==1){ //convert every month from numbers to words
         months="January";
     }
     if (month ==2){
         months = "Feburary";
     }
      if (month ==3){
         months = "March";
     }
       if (month ==4){
         months = "April";
     }
       if (month ==5){
         months = "May";
     }
       if (month ==6){
         months = "June";
     }
       if (month ==7){
         months = "July";
     }
       if (month ==8){
         months = "August";
     }
       if (month ==9){
         months = "Spetember";
     }
       if (month ==10){
         months = "October";
     }
       if (month ==11){
         months = "November";
     }
       if (month ==12){
         months = "December";
     }
     
     System.out.println("");
     System.out.println("--------------VALIDATION----------------");
     System.out.println("Your username is: "+ username);
     System.out.println("Your password is: "+ password);
     System.out.println("Your date of birth is: " +months+ " "+ day+ ","+year);
     System.out.println("Your gender is: " +gender);
     System.out.println("Your age is: "+age);
     


     
    }   
}//end class
