/*******************************************************************************
 * Project6, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 8, 2019
 * 
 * In this program, it reads a file which contains the host and property entry 
 * of the Airbnb data file. Objects containing each entry of the Airbnb host and
 * property data will be created and stored as an array in the driver class. 
 * Validation of these entry make sure entries are met with the requirements. 
 * Error will be counted if requirements are not met. Index position of the file
 * will printed out at the end of the file, including error lines and total 
 * number of lines read from the file.
*******************************************************************************/
package Assign6;



import java.time.LocalDate;
import java.time.format.*;



public class MakeObjects {

        
        
        public static String [] myArray ;
        public static AirbnbHost [] Host = new AirbnbHost [10000];
        public static AirbnbProperty [] Property = new AirbnbProperty [10000];
        
        
     public static void main(String[] args) {//main method
        String line;//host, property
        String Zip;//Zip code
        double priceamount=0,priceamount1 = 0,priceamount2 = 0;//price amount of price, security deposit and cleaning
    
         int counterror = 0; //
         int count = 0;//count lines read
         int i = 0;//count how many cycles went through and as array index
         int prop=0;//prop object created
         int hos=0;//host object created
         boolean superhost = false;//super host condition 
         String format = "M/d/yyyy";//date format
         LocalDate today = LocalDate.now();//current time
         String theDate; //the input date
         String rate;//response rate in string
         int responserate = 0;//responserate in int
         LocalDate since;//host since time
         
         
     
         while (true) { 
         try {//input file validation
            TextIO.readFile( "airbnb small with errors.txt" );  //  open the file for input.
            break;  // If succeeds, break 
         }
         catch ( IllegalArgumentException e ) { //bad file name
            System.out.println("Can't read from the file. "
                    + "Check the file name please.");
            System.exit(0);
         }
      }      
         
       
     TextIO.getln();//skip the headline
     
    
 
     
     validationloop: while (!TextIO.eof()) //to the end of file
      {   //while loop

      
        line = TextIO.getln();//read lines
        
        count++;//lines read
        
        myArray = line.split("~");//split method
       if (myArray.length !=25){ //if there is a blank in the line
            
            counterror++;
            
            continue;
        }
       


        if (myArray[0].equals("")){ //blank validation
            counterror++;
        
            continue;
        } 
        
        //System.out.println(myArray[0]);
        try {
            Integer.parseInt(myArray [0]); //integer?
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
          
               continue;
        }

        
        
        if(myArray[1].equals("")){//blank check
            counterror++;
          
            continue;
        }
        
        if (myArray[2].equals("")){//no validation
         
            
        }   

       
        if(myArray[3].equals("")){ //blank check
            counterror++;
          
            continue;
        }       
        try {
            Integer.parseInt(myArray [3]); //integer?
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }
        

        if(myArray[4].equals("")){//blank check
            counterror++;
            
            continue;
        }  
        
        
        if(myArray[5].equals("")){//blank check
            counterror++;
            
            continue;
        }   
        
        theDate=myArray[5];//put array value into variable theDate
        since = LocalDate.parse(theDate,DateTimeFormatter.ofPattern(format));
        

 
          try { //valid date?
            LocalDate.parse(theDate,DateTimeFormatter.ofPattern(format)); 
        }
        
            
            
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }
        if (since.isAfter(today)){//test whether the date is valid
            counterror++;
           
            continue;
       }
      
        
        
        if(myArray[8].equals("")){
            counterror++;
            
            continue;
        }
        
       
        if(myArray[8].equals("N/A")){ //if the respons rate is NA
             responserate = -1;//convet NA into -1
        }
        
        if(!myArray[8].equals("N/A")){//if response rate is NA
        rate = myArray[8].substring(0, (myArray[8].length()-1));//read value only before the percent sign
            
        responserate = Integer.parseInt(rate);

           if(responserate <0 || responserate>100){//test if the rate is reasonable
               counterror++;
              
               continue;
           }

       }
    
       
       if(!myArray[9].equals("t")&& !myArray[9].equals("f")){
           
 
           counterror++;
           continue;
       }

       if(myArray[9].equals("t")){
              superhost = true;
          }
          if(myArray[9].equals("f")){
              superhost = false;
          }

                 
        try {
            Integer.parseInt(myArray [10]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
              
               continue;
        }   
        
        if (Integer.parseInt(myArray [10])< 0){ //whether the value is less than one
            counterror++;
            
            continue;
        }  
        
         
        if (myArray[12].equals("")){
            counterror++;
            
            continue;
        } 

        if (myArray[13].equals("")){
            counterror++;
          
            continue;
        } 
        
        
       
        
                
        try {
            Integer.parseInt(myArray [14]); 
            
        }
        
        catch (NumberFormatException e)
        {
               
               counterror++;
              
               continue;
  
               
        }  
        
         Zip=fixZip(myArray[14]);

        if(Zip.equals("bad zip code")){
            counterror++;
            
            continue;
        }
        
        
        if (myArray[15].equals("")){
            
            
          
            continue;
        } 


        if (myArray[17].equals("")){
            counterror++;
           
            continue;
        }                 
        try {
            Integer.parseInt(myArray [17]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }   
        
        if (Integer.parseInt(myArray [17])< 1){//whether the value is less than one
            counterror++;
           
            continue;
        }          
        
        
        if (myArray[18].equals("")){
            counterror++;
           
            continue;
        }         
        try {
            Integer.parseInt(myArray [18]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
             
               continue;
        }    
        if (Integer.parseInt(myArray [18])< 0){//whether the value is negative
            counterror++;
           
            continue;
        }   
        
        
        if (myArray[19].equals("")){
            counterror++;
           
            continue;
        }         
        try {
            Integer.parseInt(myArray [19]); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
              
               continue;
        }   
        
        if (Integer.parseInt(myArray [19])< 0){//whether the value is negative
            counterror++;
            
            continue;
        }               
        
       
        
        if (myArray[20].equals("")){
            counterror++;
            
            continue;
        }
        try {
            Double.parseDouble(myArray [20].substring(1,myArray[20].length())); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               
               continue;}
        
        
        
        priceamount = StripDollarSign(myArray[20]);//calling method
        
   
        if (priceamount < 1||priceamount>30000){//whether the value is reasonable
            counterror++;
            
            continue;
        }
        

        
        if (!myArray[21].equals("")){
                    try {
            Double.parseDouble(myArray [21].substring(1,myArray[21].length())); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               
               continue;}
            
        priceamount1 = StripDollarSign(myArray[21]);//calling method
        
        if (priceamount1 < 0 ||priceamount>30000 ){//whether the value is resonbale
            counterror++;
           
            continue;
        }        
        
        }        
  

        if (!myArray[22].equals("")){
            
                try {
            Double.parseDouble(myArray [22].substring(1,myArray[22].length())); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               
               continue;}    
         
        priceamount2 = StripDollarSign(myArray[22]);//calling method
        
        if (priceamount2 < 0 ||priceamount>30000){//whether the value is negative
            counterror++;
          
            continue;
        }    
       
        }

     
     
        try {
            Integer.parseInt(myArray [23]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }   
        
        if (Integer.parseInt(myArray [23])< 0){//whether the value is negative
            counterror++;
            
            continue;
        }             
       

        if (myArray[24].equals("")){
            
          
            //continue;
        }         
        try {
            Integer.parseInt(myArray [24]); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               
               continue;
        }   
        
        if (Integer.parseInt(myArray [24])< 0 || 
                Integer.parseInt(myArray[24])>100){ //whether the value is 0-100
            counterror++;
           
            break;
            
        }             
       
        
      Property [prop]= new AirbnbProperty (Integer.parseInt(myArray [0]),
              myArray [1],myArray [2],myArray [11],
              myArray [12],myArray [13],Zip,myArray [15],myArray [16],
              Integer.parseInt(myArray [17]),Integer.parseInt(myArray [18]),
              Integer.parseInt(myArray [19]),priceamount,priceamount1,
              priceamount2,Integer.parseInt(myArray [23]),
              Integer.parseInt(myArray [24])) ;   //property object created and put into array called host, prop as index number
            
         prop++;  //prop object created
        
        
        

      Host [hos] = new AirbnbHost (Integer.parseInt(myArray [3]),myArray [4],
              since,myArray [6],myArray [7],responserate,superhost, 
              Integer.parseInt(myArray [10])); //host object created and put into array called host, hos as index number

      //System.out.println(Host[hos].gethost_id());
      //System.out.println(myArray[4]);

      
      
         for(int z=0;z<hos;z++){//increment in z, when less than number of times when error free object is created
             
                  if(Host[z].gethost_id()==Integer.parseInt(myArray[3])){ //test whether there is the same hostID repeated
                      continue validationloop; //do not count as a host and go through loop again
                  }
              }

      
      hos++;  //host obejct created  
              

     }//while loop

     System.out.println("Total lines processed: "+count);  //print out lines read
     System.out.println("Total error lines: "+counterror);//print out error lines
     
   
     System.out.println("Valid host object created: "+ hos);//print out valid host object created
     System.out.println("Valid property object created: "+ prop);//print out valid property object created
     

     System.out.println();
     System.out.println("-------------------------------------------------"
             + "-----------");
     System.out.println("The following is the host object information "
             + "at index 5:");
     System.out.println();
     System.out.println(Host[5]); //host object at index position 5
     System.out.println();
     System.out.println("-------------------------------------------------"
             + "-----------");
     System.out.println("The following is the property object information "
             + "at index 4:");
     System.out.println();
     System.out.println(Property[5]); //property object at index position 4    

    
     } //main method
     
     
    
    public static String fixZip(String inZip){ 
 
        
        if (inZip.length() >5 || inZip.length()<3){ //whether zip code length is 3-5
            
            return "bad zip code";
            
        }
        
        if(inZip.length()== 5){
            return inZip;
        }
        
        if(inZip.length()== 4){ //pad zero before zip code
            return inZip = "0"+inZip;
        }
        
        if(inZip.length()== 3){//pad zero before zip code
            return inZip = "00"+inZip;
        }
            return inZip;
        
   
    }
    
    
    public static double StripDollarSign(String inPrice){
 
        String price;
        double priceamount;
        price = inPrice.substring(1);//read the string only after the dollar sign
        
        priceamount = Double.parseDouble(price);
        return priceamount;
        

    }
  
     
}

//23, 6,7,11, 16, no need validdation