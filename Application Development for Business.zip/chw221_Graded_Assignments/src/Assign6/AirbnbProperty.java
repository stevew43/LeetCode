/*******************************************************************************
 * Project6, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 8, 2019
 * 
 * The blueprint class of AirbnbProperty which includes all the instance 
 * variables for property entries which is the data fields from number 0 to 3, 
 * and 11 to 24 in the table constructor methods, get and set methods, and 
 * toString methods with format, at the end of the class.
*******************************************************************************/
package Assign6;


public class AirbnbProperty {
    private int id; //instance variables are declared here
    private String name;
    private String summary;
    private String neighborhood;
    private String City;
    private String State;
    private String Zipcode;
    private String Property_type;
    private String Room_type;
    private int accommodates;
    private int Bathrooms;
    private int Bedrooms;
    private double Price;
    private double securitydeposit;
    private double Cleaning;
    private int Review;
    private int Review_scores_rating;
    
    
    public AirbnbProperty(int inid,String inname,String insummary,
            String inneighborhood,String inCity,String inState,String inZipcode,
            String inProperty_type,String inRoom_type,int inaccommodates,int 
                    inBathrooms,int inBedrooms,double inPrice,double 
                            insecuritydeposit,double inCleaning,int inReview, 
                            int inReview_scores_rating){//constructor containing all instance variables
        id = inid;
        name = inname;
        summary = insummary;
        //host_id = inhost_id;
        neighborhood = inneighborhood;
        City = inCity;
        State = inState;
        Zipcode = inZipcode;
        Property_type = inProperty_type;
        Room_type = inRoom_type;
        accommodates = inaccommodates;
        Bathrooms = inBathrooms;
        Bedrooms = inBedrooms;
        Price = inPrice;
        securitydeposit = insecuritydeposit;
        Cleaning = inCleaning;
        Review = inReview;
        Review_scores_rating = inReview_scores_rating;
        
    }
    
    public int getid(){  //get methods starts from here
        return id;
    }
    
    public String getname(){
        return name;
    }

    public String getsummary(){
        return summary;
    }

   // public int gethost_id(){
        //return host_id;
    //}
    
    public String getneighborhood(){
        return neighborhood;
    }

    public String getCity(){
        return City;
    }

    public String getState(){
        return State;
    }

    public String getZipcode(){
        return Zipcode;
    }

    public String getProperty_type(){
        return Property_type;
    }    
    
    public String getRoom_type(){
        return Room_type;
    }

    public int accommodates(){
        return accommodates;
    }

    public int Bathrooms(){
        return Bathrooms;
    }

    public int Bedrooms(){
        return Bedrooms;
    }

    public double Price(){
        return Price;
    }

    public double securitydeposit(){
        return securitydeposit;
    }

    public double Cleaning(){
        return Cleaning;
    }    

    public int Review(){
        return Review;
    }    

    public int Review_scores_rating(){
        return Review_scores_rating;
    }    

    
    
    
    public void setid(int theid){ //set methods start from here
        id = theid;
        }
    
    public void setname(String thename){
        name = thename;
        }
    
    public void setsummary(String thesummary){
        summary = thesummary;
        }

    
    public void setneighborhood(String theneighborhood){
        neighborhood = theneighborhood;
        }
    public void setCity(String theCity){
        City = theCity;
        }
    public void setState(String theState){
        State = theState;
        }
    public void setZipcode(String theZipcode){
        Zipcode = theZipcode;
        }
    public void setProperty_type(String theProperty_type){
        Property_type = theProperty_type;
        }
    public void setRoom_type(String theRoom_type){
        Room_type = theRoom_type;
        }
    public void setaccommodates(int theaccomodates){
        accommodates = theaccomodates;
        }
    public void setBathrooms(int theBathrooms){
        Bathrooms = theBathrooms;
        }
    public void setBedrooms(int theBedrooms){
        Bedrooms = theBedrooms;
        }
    public void setPrice(double thePrice){
        Price = thePrice;
        }
    public void setsecuritydeposit(double thesecuritydeposit){
        securitydeposit = thesecuritydeposit;
        }
    public void setCleaning(int theCleaning){
        Cleaning = theCleaning;
        }
    public void setReview(int theReview){
        Review = theReview;
        }
    public void setReview_scores_ratings(int theReview_scores_rating){
        Review_scores_rating = theReview_scores_rating;
        }    
    
   //
    
 
    public String toString(){ // toString method
        String result;
        result = "Property ID: "+ id;
        result += "\nProperty name: "+name;
        result +="\nNeighborhood: "+ neighborhood;
        result +="\nCity: "+ City;
        result +="\nState: "+ State;
        result +="\nZip code: "+ Zipcode;
        result +="\nAvailable accommodates: "+ accommodates;
        result +="\nNumber of bathrooms: "+ Bathrooms;
        result +="\nNumber of bedrooms: "+ Bedrooms;
        result +="\nPrice: $"+ String.format("%,.2f", Price); //price format
        result +="\nNumber of reviews: "+ Review;
        result +="\nRatings: "+ Review_scores_rating;
        
        return result;    
    }
    
    
}
