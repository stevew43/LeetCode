/*******************************************************************************
 * Project6, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 8, 2019
 * 
 * The blueprint class of AirbnbHost which includes all the instance variables 
 * for property entries (3-7), constructor methods, get and set methods, and 
 * toString method with format at the end of the class, also includes if 
 * statements to test whether the response rate and super host condition 
 * meets the requirementFormating of the about host output is also created 
 * in the toString methods.
*******************************************************************************/
package Assign6;

import java.time.LocalDate;
import java.time.format.*;


public class AirbnbHost {
    //instance variables are declared here
    private String host_name;//no blank
    private LocalDate host_since;//valid date
    private String Host_location;//no validation
    private String Host_about;
    private int Host_response_rate; //must be a valid number bewtween 0-100 with percent sign, cannot be blank
    boolean Host_is_superhost; //must be t or f and converted into boolean, cannot be blank
    private int host_id;
    private int Host_listings_count; //must be an integer equal to or greater than zero
    
    public AirbnbHost(int inhost_id,String inhost_name, LocalDate inhost_since,
            String inHost_location,String inHostabout, int inHost_reponse_rate, 
            boolean inHost_is_superhost, int inHost_listings_count){//constructor containing all instance variables
        
        host_name = inhost_name;
        host_since = inhost_since;
        Host_location = inHost_location;
        Host_about = inHostabout;
        Host_response_rate = inHost_reponse_rate;
        Host_is_superhost = inHost_is_superhost;
        host_id = inhost_id;
        Host_listings_count = inHost_listings_count;
        
        
    }
    
    public String gethost_name(){  //get methods starts from here
        return host_name;
    }
    
    public LocalDate gethost_since(){
        return host_since;
    }

    public String getHost_about(){
        return Host_about;
    }

    public String getHost_location(){
        return Host_location;
    }

    public int getHost_response_rate(){
        return Host_response_rate;
    }

    public boolean Host_is_superhost(){
        return Host_is_superhost;
    }

    public int gethost_id(){
        return host_id;
    }

    public int getHost_listings_count(){
        return Host_listings_count;
    }    
    
    
    
    public void sethost_name(String thehost_name){//set methods start from here
        host_name = thehost_name;
        }    

    public void sethost_since(LocalDate thehost_since){
        host_since = thehost_since;
        }
    
   
    public void setHost_location(String theHost_location){
        Host_location = theHost_location;
        }

    public void setHost_about(String theHost_about){
        Host_about = theHost_about;
        }

    public void setHost_response_rate(int theHost_response_rate){
        Host_response_rate = theHost_response_rate;
        }

    public void setHost_is_superhost(boolean theHost_is_superhost){
        Host_is_superhost = theHost_is_superhost;
        }

    public void sethost_id(int thehost_id){
        host_id = thehost_id;
        }

    public void setHost_listings_count(int theHost_listings_count){
        Host_listings_count = theHost_listings_count;
        }    
    
    
    //
    public String toString(){ // toString method

        String result;
        result = "Host name: "+ host_name;
        result +="\nHost since: "+ host_since;
        result +="\nHost location: "+ Host_location;
        result +="\nAbout the host: ";
      
        if(Host_about == null){//when host about is null
        result +="\n"+ Host_about;
        }
       
       
       if(Host_about.length()<200){ //when host about is less than 200
      
          
          for (int i=50;i<Host_about.length();i+=50){ //i increases until reaches hostabout length
          result +="\n"+ Host_about.substring(i-50,i); //print out until 50 then return line
          }
          }
       
       if(Host_about.length()>=200){//when host about is more than 200
          for (int i=50;i<201;i+=50){//i increase until 200
          result +="\n"+ Host_about.substring(i-50,i);//print out until 50 then return line  
               
         }   
         }
       
         
       if(Host_response_rate == -1){
           result+="\nResponse rate: Not available"; //convert into user friendly format
       }else{
           result+="\nResponse rate: "+ Host_response_rate+"%";//when available
       }
        
        
        if(Host_is_superhost == true){  //convert t,f into yes or no
            result +="\nSuperhost: Yes";
        }
        else if(Host_is_superhost == false){
        result +="\nSuperhost: No";
        }

        result +="\nHost ID: "+ host_id;
        result +="\nNumber of host listing count: "+ Host_listings_count;
        
        
        return result;    
    }
    
    
    
}
