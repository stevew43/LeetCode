/*******************************************************************************
 * Project4, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: October 24, 2019
 * 
 * In this program, the user will be asked about what is the user's favorite 
 * movie and TV shows. After that users are asked to enter the favorite genre
 * of the movie or the TV show. User input will validated based on the specific
 * genres provided. Lastly, a summary of users preference will be provided.
*******************************************************************************/
package Assign5;


public class Netflix {//begin class
    public static void main(String[] args)
    {
        String movie,movieg,tv,tvg;
        System.out.println("What is your favorite movie?");
        movie=TextIO.getln();//get user input for favorite movie
        System.out.println("What is your favorite TV show?");
        tv=TextIO.getln(); //get user input for favorite tv
        
        
        System.out.println("What is your favorite movie genre? "
             + "(Action,Adventure,Comedy,Drama,Horror,Science-Fiction,other)");
        movieg = getValidGenre(); //1st call of method
        
        System.out.println("What is your favorite TV show genre?");
        tvg = getValidGenre(); // 2nd call of method
        
        System.out.println("-------------------------------------");
        System.out.println("Here is a summary of your preference:");
        
        System.out.println();
        System.out.print("Your favourite movie is: "); //output of preference
        System.out.println(movie+".");
        System.out.print("Your favourite TV show is: ");
        System.out.println(tv+".");

        System.out.print("Your favourite movie genre is: "); //output of genre 
        System.out.println(movieg+".");
        System.out.print("Your favourite TV show genre is: ");
        System.out.println(tvg+".");
        
        
        
    }
    
    public static String getValidGenre(){ //begin method
       String genre; 
        genre= TextIO.getln();

        while(true){
            if(genre.equalsIgnoreCase("Action")||genre.equalsIgnoreCase
        ("Adventure")||genre.equalsIgnoreCase("Comedy")||genre.equalsIgnoreCase
        ("Drama")||genre.equalsIgnoreCase("Horror")||genre.equalsIgnoreCase
        ("Science-Fiction")||genre.equalsIgnoreCase("other")){ //when user input is valid
             break;   
            }
        System.out.println("Enter a valid genre:");   //not valid case
        genre= TextIO.getln();
        }
        
        return genre;
        
        
    } //end method
    
    

    
}// end class
