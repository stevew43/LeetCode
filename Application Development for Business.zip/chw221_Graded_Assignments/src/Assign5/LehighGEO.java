/*******************************************************************************
 * Project4, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: October 24, 2019
 * 
 * In this program, it reads a file which contains the geographical and 
 * demographical information of Lehigh current students from 2017 to 2019. The
 * program have the functionality to identify errors in the file such as typo, 
 * missing information, or unreasonable data. Once the input file is read, it 
 * will provide a output containing the number of students based of their
 * nationality, and a summary of how many lines of file is read, and how many
 * lines contains any error.
*******************************************************************************/
package Assign5;


public class LehighGEO {
    public static void main(String[] args){
        
        int count = 0;
        int studentnumber = 0; //student amount
        int uscitizen19 = 0; //us citizen in 2019
        int uscitizen18 = 0;
        int uscitizen17 = 0;
        int nonuscitizen19 = 0;//non us citizen in 2019
        int nonuscitizen18 = 0;
        int nonuscitizen17 = 0;
        String line;
        String [] myArray;
      int counterror = 0; //when there is error in the array (file)
      int countvalid = 0;//valid lines
        
       
        
       
       while (true) {
         try {
            TextIO.readFile( "lehighGeoLocationShortError.txt" );  //  open the file for input.
            break;  // If succeeds, break 
         }
         catch ( IllegalArgumentException e ) { //bad file name
            System.out.println("Can't read from the file. "
                    + "Check the file name please.");
            System.exit(0);
         }
      } 
        
             
      TextIO.getln();// get info start from 2nd line
      
      while (!TextIO.eof()) //to end of file
      {
        line = TextIO.getln();
        count++;
        //System.out.println(line);
        myArray = line.split(",");
        if (myArray.length !=4){ //if there is a blank in the line
            
            counterror++;
            continue;
        }
        
        
   
        
        
        if (!myArray[0].equals("201940")&&!myArray[0].equals("201840")&&
                !myArray[0].equals("201740")) // if the year is not in good format
        {
          counterror++;  
          continue;
        }
       
         try {
            studentnumber = Integer.parseInt(myArray [3]); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               continue;
        }
        
         if(studentnumber >2000 || studentnumber<0){ //test if the number is reasonable
           
            counterror++;
            continue;
        
        }
         
         if ((!myArray[1].equals("Non-Us Citizens")&&!myArray[1].equals
        ("Non-US Citizens"))&&!myArray[1].equals("US Citizens/Residents"))  //test if the nationality is correct
         {
             counterror++;    
             continue;
         }
           

         if (myArray[1].equals("US Citizens/Residents")&& myArray[0]
                 .equals("201940")) //count 2019 us citizens
         {
             uscitizen19 = uscitizen19 + Integer.parseInt(myArray[3]);// add up the amount
             continue;
         }
         
         if (myArray[1].equals("US Citizens/Residents")&& myArray[0]
                 .equals("201840")) //count 2018 us citizens
         {
             uscitizen18 = uscitizen18 + Integer.parseInt(myArray[3]);
             continue;
         }
         
         if (myArray[1].equals("US Citizens/Residents")&& myArray[0].
                 equals("201740"))//count 2017 us citizens
         {
             uscitizen17 = uscitizen17 + Integer.parseInt(myArray[3]);
             continue;
         }
         
          if ((myArray[1].equals("Non-Us Citizens")||myArray[1].
                  equals("Non-US Citizens"))&& myArray[0].equals("201940"))//count 2019 non us citizens
         {
             nonuscitizen19 = nonuscitizen19 + Integer.parseInt(myArray[3]);
             continue;
         }
                  
          if ((myArray[1].equals("Non-Us Citizens")||myArray[1].
                  equals("Non-US Citizens"))&& myArray[0].equals("201840"))//count 2018 us citizens
         {
             nonuscitizen18 = nonuscitizen18 + Integer.parseInt(myArray[3]);
             continue;
         }         
         
          if ((myArray[1].equals("Non-Us Citizens")||myArray[1].
                  equals("Non-US Citizens"))&& myArray[0].equals("201740"))//count 2017 us citizens
         {
             nonuscitizen17 = nonuscitizen17 + Integer.parseInt(myArray[3]);
             
         }         
         
        
        }
      
   
       
        
        System.out.println("Lehigh University Undergraduate Students\n");//print out the table
        
        System.out.println("\tUS\t\tNon US");
        System.out.println("\tCitizens\tCitizens");
        System.out.println("\t--------\t--------");
        
        System.out.print("2019:\t");
        System.out.printf("%,8d",uscitizen19);
        System.out.print("\t");
        System.out.printf("%,8d",nonuscitizen19);
        System.out.println();
        System.out.println();
  
        
        System.out.print("2018:\t");
        System.out.printf("%,8d",uscitizen18);
        System.out.print("\t");
        System.out.printf("%,8d",nonuscitizen18);
        System.out.println();
        System.out.println();
  
        
        System.out.print("2017:\t");
        System.out.printf("%,8d",uscitizen17);
        System.out.print("\t");
        System.out.printf("%,8d",nonuscitizen17);
        System.out.println();
        
        countvalid = count - counterror;//the valid lines is total lines subtract error lines
        
        System.out.println();
        System.out.print("Total data lines read from the file: "); //amount of student
        System.out.printf("%,d",count);
        System.out.println (".");
        System.out.print("Total valid data lines: ");// valid lines
        System.out.printf("%,d",countvalid);
        System.out.println ("");
        System.out.print("Total error data lines: "); // error lines
        System.out.printf("%,d",counterror);
        System.out.println ("");
        
    }
}
