/*******************************************************************************
 * Project4, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: October 24, 2019
 * 
 * In this program, it prompts the user to enter ten exam scores. After 
 * user input, the mean and standard deviation of the ten scores will be 
 * calculated. After that, the program will ask the user if the user wants to 
 * give the exam a curve and the curve should below 20 points and any of the 
 * exam score should not exceed 100. Lastly, the mean and standard deviation
 * of the new score will be calculated.
*******************************************************************************/
package Assign5;


public class ExamCurve {
    static double score;
  
    static double list[]=new double[10]; // the array list for score
    static String choice;//whether the user want to curve
    static double amount; //curve amount
    static double mean, sd;// mean and standard deviation
 public static void main(String[] args)
    {
      int i;  // the array index
     
     for (i = 0; i < 10; i++) { //user input scores into array
         System.out.println("Please enter your exam score "+(i+1)+":");
         score=TextIO.getlnDouble();
         while(true){ //validation for score range 0-100
             
             if (score>=0 && score<=100){
              
              list[i]=score;   //store score into the array list
              break;
             }
             System.out.println("Must between 0 and 100"); //when score exceed 100
             score=TextIO.getlnDouble(); 
         }
         
             
    }   

        
        
        calcMeanSD(); //first call of method
        
        
        System.out.println("Would you like to curve your scores with a fixed "
                + "amount?(Y/N)");

        while (true){ 
        choice = TextIO.getln();// whether the user want to curve
        choice = choice.toUpperCase();          
            if (choice.equals("Y")){ //case when user wants to curve
                if (list[0]==100 ||list[1]==100 ||list[2] 
                        ==100||list[3]==100||list[4]==100||list[5]==100||list[6]
                        ==100||list[7]==100||list[8]==100||list[9] ==100)
                { // the case when there is already a 100 in one of the scores
               System.out.println();
               System.out.println("There is nothing you can curve, because one "
                        + "of your grade is 100 already.");
                  break;  
            } 
                
                
                else
              System.out.println("Please enter the amount you would like to"
                      + " curve (0-20): " );  
             amount = TextIO.getlnDouble();
             while (true){
                 if(amount<=20 && amount>=0){ //test for curve amount between 0 to 20
                     break;
                 }
                 else {
                     System.out.println("Please curve an amount 0-20");//when curve amount exceed 20
                     amount = TextIO.getlnDouble();
                 }
             }

             
             
             while (true){ //case when there is no score exceed 100 after the curve
                if ((list[0] + amount)<=100 &&(list[1] + amount)<=100&&(list[2] 
                        + amount)<=100&&(list[3] + amount)<=100&&(list[4] + 
                        amount)<=100&&(list[5] + amount)<=100&&(list[6] + 
                        amount)<=100&&(list[7] + amount)<=100&&(list[8] + 
                        amount)<=100&&(list[9] + amount)<=100 )
                { // test whether the new score exceeds 100
             list[0] = list[0] + amount;
             list[1] = list[1] + amount;
             list[2] = list[2] + amount;
             list[3] = list[3] + amount;
             list[4] = list[4] + amount;
             list[5] = list[5] + amount;
             list[6] = list[6] + amount;
             list[7] = list[7] + amount;
             list[8] = list[8] + amount;
             list[9] = list[9] + amount;
                 break;
                }
                else {
               System.out.println("Curve a little lower, one of the grades "
                       + "exceeds 100");//exceed 100
                amount = TextIO.getlnDouble();  //get input again
                }
                }
             
            break;
            }
            else if (choice.equals("N")){ //case when not to curve
                System.out.println("Thank you, goodbye");
                break;
                
            }
            
            
            
            else{
                 System.out.println("Please type in Y or N:"); // case when typed in sth else
       
            }
            
            
        }
        System.out.println();
        System.out.println("Your 10 exam scores follow:"); // list out the new grade
        System.out.println(list[0]);
        System.out.println(list[1]);
        System.out.println(list[2]);
        System.out.println(list[3]);
        System.out.println(list[4]);
        System.out.println(list[5]);
        System.out.println(list[6]);
        System.out.println(list[7]);
        System.out.println(list[8]);
        System.out.println(list[9]);
        
        
        calcMeanSD(); //second call of method
        
        
        
    }   
 
 public static void calcMeanSD(){ //mean and sd calculation
   

        mean = (list[0]+list[1]+list[2]+list[3]+list[4]+list[5]+list[6]+
                list[7]+list[8]+list[9])/10; //mean calculation
        sd = java.lang.Math.sqrt(((((list[1]-mean)*(list[1]-mean))+
                ((list[2]-mean)*(list[2]-mean))+((list[3]-mean)*(list[3]-mean))
                +((list[4]-mean)*(list[4]-mean))+((list[5]-mean)*(list[5]-mean)
                )+((list[6]-mean)*(list[6]-mean))+((list[7]-mean)*(list[7]-mean)
                )+((list[8]-mean)*(list[8]-mean))+((list[9]-mean)*(list[9]-mean)
                )+((list[0]-mean)*(list[0]-mean)))/10)); // SD calculation
 
        System.out.println("Your mean score is "+mean+"."); //print out mean
        System.out.print("Your score standard deviation is ");
        System.out.printf("%4.2f",sd); // print out sd
        System.out.println (".");
        
 }
 

}
