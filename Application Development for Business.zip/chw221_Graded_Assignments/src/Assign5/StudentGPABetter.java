/*******************************************************************************
 * Project4, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: October 24, 2019
 * 
 * In this program, it asks the user to input the current GPA and total credits
 * earned. After that, it prompts user to enter the courses and credits including
 * GPAs in the current semester. Then a new semester GPA will be generated, and
 * added to the overall GPA. The new cumulative GPA will be output to the user
 * indicating whether the cumulative GPA will increase or decrease based on
 * the performance of the user in current semester.
*******************************************************************************/
package Assign5;

public class StudentGPABetter {
    
 
   

  public static void main(String[] args)
    {
   double numbergrade = 0, classcredit = 0,semestergpa,semesterquality = 0,
           totalgpa, currentgpa, currentcredits, semestercredits = 0,
           currentquality,insemesterGPA, incumulativeGPA,inOverallGPA,
           difference1,difference2;
   int count;//to count for loop times
   String classgrade;
   
   System.out.println("What is your current GPA?");
   currentgpa=TextIO.getlnDouble(); //get current gpa
    
    while (currentgpa < 0.0 || currentgpa > 4.0){ //current gpa validation
            System.out.println("Please enter a valid GPA.");
            System.out.print("Current overall GPA: ");
            currentgpa = TextIO.getlnDouble();
        }
    
    System.out.println("What is your current credits?");
    
    currentcredits=TextIO.getlnDouble(); // get current credits

    for (int n=0; n<5; n++){ // for loop starts
    count = n+1; //count for the class number
    System.out.println("What is your credit for class " + count+ "?" ) ;
    classcredit = getValidCredits(); //method call
    classgrade = getValidGrade(); //method call
    numbergrade = calcNumericWeight(classgrade);//method call

          
    semestercredits = semestercredits + classcredit;//calculation for semester credits
    semesterquality = semesterquality + classcredit * numbergrade; //calculation for semester quality  
      
    }    //for loop ends
    
    
    semestergpa = semesterquality / semestercredits;//semester gpa
    currentquality = currentgpa*currentcredits; //current quality points
    totalgpa = (currentquality + semesterquality)
            /(currentcredits + semestercredits); //total gpa plus the semester
    
    insemesterGPA = semestergpa; //semester gpa
    incumulativeGPA = totalgpa;//total gpa
    inOverallGPA = currentgpa;//current gpa
    difference1 = incumulativeGPA - inOverallGPA; //when semestergpa > currentgpa
    difference2 = inOverallGPA - incumulativeGPA; //when semestergpa < currentgpa
    
    
    
    if (semestergpa > currentgpa){ //grade increases
        System.out.println("-------------------------------------");
        System.out.println ("That’s great!");
        System.out.print("Your cumulative GPA increases by ");
        System.out.printf("%4.2f",difference1);//output the differences
        System.out.println();
        printGPA(insemesterGPA, incumulativeGPA, inOverallGPA);
    }
    if (semestergpa < currentgpa){ //grade decreases
        System.out.println("-------------------------------------");
        System.out.println ("Please work harder.");
        System.out.print("Your cumulative GPA decreases by ");
        System.out.printf("%4.2f",difference2);//output the differences
        System.out.println();
        printGPA(insemesterGPA, incumulativeGPA, inOverallGPA);
    }
    if (semestergpa == currentgpa){ //grade remains
        System.out.println("-------------------------------------");
        System.out.println ("Cumulative GPA remains the same.");
        printGPA(insemesterGPA, incumulativeGPA, inOverallGPA);
    }
        
   
        
        
    }
public static double calcNumericWeight(String inletter){  //convert letter grade to number
    
       double numbergrade;
       switch (inletter) { //course 1 conditions
          case "A":
              numbergrade = 4.0;
              break;
          case "A-":
              numbergrade = 3.7;
              break;
          case "B+":
              numbergrade = 3.3;
              break;
          case "B":
              numbergrade = 3.0;
              break;
          case "B-":
              numbergrade = 2.7;
              break;
          case "C+":
              numbergrade = 2.3;
              break;
          case "C":
              numbergrade = 2.0;
              break;
          case "C-":
              numbergrade = 1.7;
              break;
          case "D+":
              numbergrade = 1.3;
              break;
          case "D":
              numbergrade = 1.0;
              break;
          default:
              numbergrade = 0.0;
              break;
      }
    
    
    return numbergrade;
   
}
     public static double getValidCredits(){ //credit validation
      double classcredit;
    
      classcredit = TextIO.getlnDouble();
      
      while (classcredit < 0 || classcredit > 6){ //should not below 0 or over 6
                System.out.println("Please enter a reasonable amount of credits.");
                System.out.print("Credits: ");
                classcredit = TextIO.getlnDouble();//get credit again
            }
          
      return classcredit;
         
     }
     
     public static String getValidGrade(){ // grade validation
         System.out.println("What letter grade did you receive for this class?");
         String classgrade;
         
         classgrade = TextIO.getln();
         classgrade = classgrade.toUpperCase();
         
          while (!classgrade.equals("A") && !classgrade.equals("A-") &&
                  !classgrade.equals("B+") &&!classgrade.equals("B") && 
                  !classgrade.equals("B-") && !classgrade.equals("C+") && 
                  !classgrade.equals("C") && !classgrade.equals("C-") &&
                  !classgrade.equals("D+") && !classgrade.equals("D") &&
                  !classgrade.equals("F")){
                System.out.println("Please enter a valid letter grade."); //when entered something else
                
                classgrade = TextIO.getln();
                classgrade = classgrade.toUpperCase();
            }
         
      return classgrade;
         
     }
     
    public static void printGPA(double insemesterGPA, double incumulativeGPA,
double inOverallGPA){ //print out the gpa results
        
        System.out.print("Your semester GPA is ");
        System.out.printf("%4.2f", insemesterGPA);
        System.out.println();
        System.out.print("Your new cumulative GPA is ");
        System.out.printf("%4.2f", incumulativeGPA);
        System.out.println();
        System.out.print("Your original GPA is ");
        System.out.printf("%4.2f", inOverallGPA);
        System.out.println();
        
        
        
    } 


}
