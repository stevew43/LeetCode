/*******************************************************************************
 * Project8, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: December 13, 2019
 * 
 * In this class, the search panel is created. User can search for Airbnb 
 * properties information by typing in the property ID, selecting desired 
 * bedroom number, or typing a target price. The property information will show 
 * in the JTextarea when user click on any of the three search buttons. The user
 * can only search one criteria each time, thus user cannot search a combination
 * of price and bedroom. There is also a user input validation for the property 
 * ID, bedroom selection, and price input. If there contains a problem, the user
 * will be alerted with specific error of input. When user click on Clear, all 
 * information will be cleared from the window, including user input.Go back 
 * button returns to the menu.(Previous problems have been fixed)
*******************************************************************************/
package Assign8;


import java.awt.GridLayout;
import javax.swing.JPanel;
import java.awt.event.*;
import javax.swing.*;



public class SearchPanel extends JPanel implements ActionListener {
    
       
        JLabel Instructions = new JLabel("Search specific property ID:"); //instruction for property search
        JLabel Instructions1 = new JLabel("Search desirable bedroom number:"); //instruction for bedroom search
        JLabel Instructions2 = new JLabel("Search price lower than:"); //instruction for price search
        JLabel Info = new JLabel("Property information:"); //instruction
        JTextField Input = new JTextField(2); //text field for search input
        JTextField Priceinput = new JTextField(2); //text field for price input
        JButton Search = new JButton("Search ID"); //search id button
        JButton Search1 = new JButton("Search Bedroom"); //search bedroom button
        JButton Search2 = new JButton("Search Prices"); //search prices button
        JButton Exit = new JButton("Go Back");  //return button
        JButton Clear = new JButton("Clear");  //clear button
        
  
        
        JTextArea SearchResult = new JTextArea ("",3,2);    //adding jtextarea
        
        
        JScrollPane Scroller = new JScrollPane( SearchResult ); //adding jscrollpane
        
                 String[] BedroomsString = { "","0", "1", "2", "3","4","5","6",
                     "7","8","9","10"}; //Bedroom number
                 JComboBox BedroomsChoice = new JComboBox(BedroomsString);//bedroom choice combobox

       
       public SearchPanel(){//search panel
           
           setLayout(null); //free layout
           setBorder( BorderFactory.createEtchedBorder() ); 
           
          
        SearchResult.setEditable(false); //not editable 
         add(Instructions); //adding instruction
          Instructions.setBounds(20,30,200,20);
          add(Instructions1); //adding instruction
          Instructions1.setBounds(20,100,250,20);
          add(Instructions2); //adding instruction
          Instructions2.setBounds(20,170,250,20);
         add(Input);
          Input.setBounds(20,50,120,40);
         add(Search);
          Search.setBounds(150,50,100,40);
         add (Search1);
         Search1.setBounds(150,120,150,40);
         add (Search2);
         Search2.setBounds(150,190,150,40);
         add(Exit);
          Exit.setBounds(130,590,100,40);
         add(Clear);
          Clear.setBounds(20,590,100,40);
         add(Info);
         Info.setBounds(20,240,120,20);
         add(Scroller);
          Scroller.setBounds(20,270,440,300);
          add(BedroomsChoice);
          BedroomsChoice.setBounds(20,120,120,40);
          add(Priceinput);
          Priceinput.setBounds(20,190,120,40);
         
         Search.addActionListener(this);//adding action listener
         Search1.addActionListener(this);//adding action listener
         Search2.addActionListener(this);//adding action listener
         Exit.addActionListener(this);//adding action listener
         Clear.addActionListener(this);//adding action listener
         
       }
    
    public void actionPerformed(ActionEvent e){
        
        
        String inputvalue; // the input for id value
        inputvalue = Input.getText(); //txt get from jtextfield
        int inputid; //the input property id integer form (be used to parse int later)     
      
         String price;//price (lower) than
         price = Priceinput.getText();//get the price input value after user type in
        
         
        int iderrorcount = 0;//count for when there is a error when user is trying to search using specific id
        int priceerrorcount=0; //count for when there is a error when user is trying to search using price lower than
        int bedroomerrorcount = 0; //count for when there is a error when user is trying to search using bedroom number 
        
        

        int inputbedroom; // the input for bedroom
        inputbedroom = BedroomsChoice.getSelectedIndex();//get selected index for bedroom drop down
        double inputprice;// the input for price per night
        


    
        
     String op = e.getActionCommand(); //get actions


 
   
    if(op.equals("Search ID")){ //when user click searh ID
        
        clear();//calling the clear method first
        
        try {
          inputid = Integer.parseInt(inputvalue); //parse value into integer   
         }
         catch (NumberFormatException i) { //catching the error   
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid integer for property ID."); //error message pop up
            return;
         }
        
                    
       if(inputid<=0){ //if input id is less than zero
           JOptionPane.showMessageDialog( null, "Property ID must be greater "
                   + "than 0.");    
       }   

  
        for(int i =0; i < (MakeObjects.prop);i++){//going through for loop, length equal to how much property objects created

            if(MakeObjects.Property[i].getid() != inputid){ //if id does not match
                
            iderrorcount++;//id error ++
            }      
        }
        
        if (iderrorcount == MakeObjects.prop){ //case when all the spot does not meet requirement (has error)
            
            JOptionPane.showMessageDialog( null, "Cannot find property with ID "
                    +inputid+"."); //error message pop up
        }
        
        if (iderrorcount != MakeObjects.prop){ //case when there is no error
            
                    for(int i =0; i < (MakeObjects.prop);i++){ // going through for loop, length equal to how much property objects created

       
            if(MakeObjects.Property[i].getid() == inputid){//if id mathces
                SearchResult.setText("*****************************************"
                        + "\n"+MakeObjects.Property[i].toString());//print out the property information
            } 
   
        }
                          
        }      
    }
    
    
     if(op.equals("Search Bedroom")){//when user click on search bedroom
        clear();//calling the clear method first
         
         inputbedroom=inputbedroom-1;//the index number is actuall number -1, because first default option is blank
         
         
         
         if(inputbedroom == -1){//if the oprion is blank (default value)
             JOptionPane.showMessageDialog( null, "Bedroom number cannot be"
                     + " blank.");
         }
         
         else
            for(int i =0; i < (MakeObjects.prop);i++){// going through for loop, length equal to how much property objects created

       
            if(MakeObjects.Property[i].getBedrooms() != inputbedroom){ //if the bedroom does not match
                
            bedroomerrorcount++;//bedroom error count increases
            } 
            
        }
        
        if (bedroomerrorcount == MakeObjects.prop){ //case when every property array list does not meet requirement
            JOptionPane.showMessageDialog( null, "Cannot find property with "+
                    inputbedroom+ " bedrooms."); //error message pop up
        }
        
        if (bedroomerrorcount != MakeObjects.prop){ //case when the array does not contain all error, but some errors, (which will not printed out)
            
                    for(int i =0; i < (MakeObjects.prop);i++){// going through for loop, length equal to how much property objects created

       
            if(MakeObjects.Property[i].getBedrooms() == inputbedroom){//when there is a match of bedroom number
                
                
                SearchResult.append("\n");  
                SearchResult.append("*****************************************"
                        + "\n"+MakeObjects.Property[i].toString());//print out the property information
               
            } 
   
        }
                 
            
        }
     }

     if(op.equals("Search Prices")){
        
          clear();//calling the clear method first
         
        try {
          inputprice = Double.parseDouble(price); //parse value into integer
           
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid number."); //error message pop up
            return;
         }
        
                    
       if(inputprice<=0){//when price is lower than zero
          JOptionPane.showMessageDialog( null, "Price must be greater than 0.");
          
       }   


          
           for (int i =0; i<(MakeObjects.prop);i++){//going through for loop, length equal to how much property objects created
             if(MakeObjects.Property[i].getPrice() > inputprice){//case when the propert price is higher than the user input
            
                  priceerrorcount++;//price error will increase
                 
       
             } 
           }
                 
           
           if (priceerrorcount == (MakeObjects.prop) ){//if is no mathch, all errors
            
                JOptionPane.showMessageDialog( null, "Cannot find property with"
                        + " price less than $"+inputprice+".");
           }
       
 
                 for (int i =0; i<(MakeObjects.prop);i++){//going through for loop, length equal to how much property objects created
      
           if (MakeObjects.Property[i].getPrice() <= inputprice){//when price is lower than user input
                SearchResult.append("\n");  
                SearchResult.append("*****************************************"
                        + "\n"+MakeObjects.Property[i].toString());//print out property information
               }
              }         
           }


     
     if(op.equals("Clear")){   
        clear();//calling the clear method 
        
    }
     
     if(op.equals("Go Back")){ 
     
             
         clear();//calling the clear method first
       
        MainWindow.mainGUI.setVisible(true); //show main gui
        MainWindow.searchGUI.setVisible(false);//hide search window
    }
}   
    
    public void clear(){  //fixed from assign7, added a clear method here. 
        Input.setText(""); //clearing input
        SearchResult.setText(""); //clearing search result
        BedroomsChoice.setSelectedItem("");//clear bedroom
        Priceinput.setText("");//clearprice 
    }
    
    
}
