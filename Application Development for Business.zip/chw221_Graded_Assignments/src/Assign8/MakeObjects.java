/*******************************************************************************
 * Project8, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: December 13, 2019
 * 
 * In this class, when the driver class the executed it reads a file which 
 * contains the host and property entry of the Airbnb data file. Objects 
 * containing each entry of the Airbnb host and property data will be created 
 * and stored as an array in the class. Validation of these entry make sure 
 * entries are met with the requirements. Error will be counted if requirements
 * are not met. If there is a problem in the entry thus that property or host 
 * object will not be created and added to the array. At the end, a window will 
 * pop up for how many property objects have been loaded.(Previous problems have
 * been fixed)
*******************************************************************************/
package Assign8;


import Assign6.TextIO;
import java.time.LocalDate;
import java.time.format.*;
import javax.swing.JOptionPane;



public class MakeObjects {

        
        
         public static String [] myArray ;
         public static AirbnbHost [] Host = new AirbnbHost [10000];
         public static AirbnbProperty [] Property = new AirbnbProperty [10000];
        
         public static int zerob=0;//counter for zero bedroom
         public static int oneb=0;//counter for one bedroom
         public static int twob=0;//counter for two bedroom
         public static int threeb=0;//counter for three bedroom
         public static int fourb=0;//counter for four bedroom
         public static int fiveb=0;//counter for five or more bedroom
         
         public static int prop=0;//counter for property objects created
         public static int hos=0;//counter for host objects created
         
public static void loadAirbnb (){

        String line;//host, property
        String Zip;//Zip code
         int counterror = 0; //count error lines
         int count = 0;//count lines read
         int i = 0;//count how many cycles went through and as array index
         double priceamount=0,priceamount1 = 0,priceamount2 = 0;//the amount of price, security deposit and cleaning
         
         int propertyidparse; //the value parsed into integer //fixed from assign6, putting all parsed value into variables first
         int hostidparse;//the value parsed into integer
         int hostlistingparse;//the value parsed into integer
         int accommodatesparse;//the value parsed into integer
         int bathroomparse;//the value parsed into integer
         int bedroomparse;//the value parsed into integer
         int reviewparse;//the value parsed into integer
         int ratingparse;//the value parsed into integer
        
         boolean superhost = false;//super host condition 
         String format = "M/d/yyyy";//date format
         LocalDate today = LocalDate.now();//current time
         String theDate; //the input date
         String rate;//response rate in string
         int responserate = 0;//responserate in int
         LocalDate since;//host since time
        
         while (true) { 
         try {//input file validation
            TextIO.readFile( "airbnb small no errors.txt" );  //  open the file for input.
            break;  // If succeeds, break 
         }
         catch ( IllegalArgumentException e ) { //bad file name
            System.exit(0);
         }
      }      
          
     TextIO.getln();//skip the headline
     

     validationloop: while (!TextIO.eof()) //to the end of file
      {   //while loop

      
        line = TextIO.getln();//read lines
        
        count++;//lines read
        
        myArray = line.split("~");//split method
       if (myArray.length !=25){ //if there is a blank in the line
            
            counterror++;
            
            continue;
        }
       


        if (myArray[0].equals("")){ //blank validation
            counterror++;
        
            continue;
        } 
        
        try {
            propertyidparse = Integer.parseInt(myArray [0]); //integer?
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
          
               continue;
        }


        if(myArray[1].equals("")){//blank check
            counterror++;
          
            continue;
        }
        
        if (myArray[2].equals("")){//no validation
         
            
        }   

       
        if(myArray[3].equals("")){ //blank check
            counterror++;
          
            continue;
        }       
        try {
            hostidparse = Integer.parseInt(myArray [3]); //integer?
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }
        

        if(myArray[4].equals("")){//blank check
            counterror++;
            
            continue;
        }  
        
        
        if(myArray[5].equals("")){//blank check
            counterror++;
            
            continue;
        }   
        
        theDate=myArray[5];//put array value into variable theDate
        since = LocalDate.parse(theDate,DateTimeFormatter.ofPattern(format));
        

          try { //valid date?
            LocalDate.parse(theDate,DateTimeFormatter.ofPattern(format)); 
        }
        
            
            
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }
        if (since.isAfter(today)){//test whether the date is valid
            counterror++;
           
            continue;
       }
      
        
        
        if(myArray[8].equals("")){
            counterror++;
            
            continue;
        }
        
       
        if(myArray[8].equals("N/A")){ //if the respons rate is NA
             responserate = -1;//convet NA into -1
        }
        
        if(!myArray[8].equals("N/A")){//if response rate is NA
        rate = myArray[8].substring(0, (myArray[8].length()-1));//read value only before the percent sign
            
        responserate = Integer.parseInt(rate);
        
        try{ //try catch response rate error //fixed from assign6.
            
            Integer.parseInt(rate);
            
        }
        catch (NumberFormatException e){
                counterror++;
                continue;
        }

           if(responserate <0 || responserate>100){//test if the rate is reasonable
               counterror++;
              
               continue;
           }

       }
    
       
       if(!myArray[9].equals("t")&& !myArray[9].equals("f")){
           
 
           counterror++;
           continue;
       }

       if(myArray[9].equals("t")){
              superhost = true;
          }
          if(myArray[9].equals("f")){
              superhost = false;
          }

                 
        try {
            hostlistingparse = Integer.parseInt(myArray [10]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
              
               continue;
        }   
        
        if (hostlistingparse < 0){ //whether the value is less than one
            counterror++;
            
            continue;
        }  
        
         
        if (myArray[12].equals("")){
            counterror++;
            
            continue;
        } 

        if (myArray[13].equals("")){
            counterror++;
          
            continue;
        } 
        
        
        
        
                
        try {                               //fixed from assign6, try catch first then call method
            Integer.parseInt(myArray [14]); 
            
        }
        
        catch (NumberFormatException e)
        {
               
               counterror++;
              
               continue;
  
        }  
        
        Zip=fixZip(myArray[14]);  

        if(Zip.equals("bad zip code")){
            counterror++;
            
            continue;
        }
        
        if (myArray[15].equals("")){
    
            continue;
        } 


        if (myArray[17].equals("")){
            counterror++;
           
            continue;
        }                 
        try {
            accommodatesparse = Integer.parseInt(myArray [17]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }   
        
        if (accommodatesparse < 1){//whether the value is less than one
            counterror++;
           
            continue;
        }          
        
        
        if (myArray[18].equals("")){
            counterror++;
           
            continue;
        }         
        try {
            bathroomparse = Integer.parseInt(myArray [18]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
             
               continue;
        }    
        if (bathroomparse < 0){//whether the value is negative
            counterror++;
           
            continue;
        }   
        
        
        if (myArray[19].equals("")){
            counterror++;
           
            continue;
        }         
        try {
            bedroomparse = Integer.parseInt(myArray [19]); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
              
               continue;
        }   
        
        if (bedroomparse < 0){//whether the value is negative
            counterror++;
            
            continue;
        }    
        
        if (bedroomparse== 0){//whether the value is negative
            zerob++;
            
         
        }    
        if (bedroomparse== 1){//whether the value is negative
            oneb++;
            
          
        }    
        if (bedroomparse== 2){//whether the value is negative
            twob++;
            
      
        }    
        if (bedroomparse==3){
            threeb++;
            
        
        }    
        if (bedroomparse==4){
            fourb++;
            
         
        }       
        if (bedroomparse==5 ||bedroomparse >5){
            fiveb++;

        } 

 
        
       
        
        if (myArray[20].equals("")){
            counterror++;
            
            continue;
        }
        try {
            Double.parseDouble(myArray [20].substring(1,myArray[20].length())); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;}
        
        
        
        priceamount = StripDollarSign(myArray[20]);//calling method
        
   
        if (priceamount < 1||priceamount>30000){//whether the value is reasonable
            counterror++;
            
            continue;
        }
        

        
        if (!myArray[21].equals("")){
         try {
            Double.parseDouble(myArray [21].substring(1,myArray[21].length())); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               
               continue;}
            
        priceamount1 = StripDollarSign(myArray[21]);//calling method
        
        if (priceamount1 < 0 ||priceamount>30000 ){//whether the value is resonbale
            counterror++;
           
            continue;
        }        
        
        }        
  

        if (!myArray[22].equals("")){
            
                try {
            Double.parseDouble(myArray [22].substring(1,myArray[22].length())); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               
               continue;}    
         
        priceamount2 = StripDollarSign(myArray[22]);//calling method
        
        if (priceamount2 < 0 ||priceamount>30000){//whether the value is negative
            counterror++;
          
            continue;
        }    
       
        }

     
     
        try {
            reviewparse = Integer.parseInt(myArray [23]); 
        }
        
        catch (NumberFormatException e) 
        {
               counterror++;
               
               continue;
        }   
        
        if (reviewparse < 0){//whether the value is negative
            counterror++;
            
            continue;
        }             
       

        if (myArray[24].equals("")){
            
          
            //continue;
        }         
        try {
            ratingparse = Integer.parseInt(myArray [24]); 
        }
        
        catch (NumberFormatException e) // when the student number is a double
        {
               counterror++;
               
               continue;
        }   
        
        if (ratingparse < 0 || 
                ratingparse >100){ //whether the value is 0-100
            counterror++;
           
            break;
            
        }             
       
        
      Property [prop]= new AirbnbProperty (propertyidparse,     //fixed from assign6, putting parsed value into variables, then put into object array.
              myArray [1],myArray [2],myArray [11],
              myArray [12],myArray [13],Zip,myArray [15],myArray [16],
              accommodatesparse,bathroomparse,
              bedroomparse,priceamount,priceamount1,
              priceamount2,reviewparse,
              ratingparse) ;   //property object created and put into array called host, prop as index number
            
         prop++;  //property object created
         
         
                                     //fixed from assign6, putting the host duplicate validation in front of the host object array
              for(int z=0;z<hos;z++){//increment in z, when less than number of times when error free object is created
             
                  if(Host[z].gethost_id()==hostidparse){ //test whether there is the same hostID repeated
                      continue validationloop; //do not count as a host and go through loop again
                  }
              }                
                   
 
        

      Host [hos] = new AirbnbHost (hostidparse,myArray [4],
              since,myArray [6],myArray [7],responserate,superhost, 
              hostlistingparse); //host object created and put into array called host, hos as index number


      
      hos++;  //host obejct created  
              

     }//while loop

 

     JOptionPane.showMessageDialog( null, prop + " Airbnb objects have been "
             + "loaded."); //how many property objects have been loaded
     } //main method
     
     
    
    public static String fixZip(String inZip){ //fix zip method
 
        
        if (inZip.length() >5 || inZip.length()<3){ //whether zip code length is 3-5
            
            return "bad zip code";
            
        }
        
        if(inZip.length()== 5){
            return inZip;
        }
        
        if(inZip.length()== 4){ //pad zero before zip code
            return inZip = "0"+inZip;
        }
        
        if(inZip.length()== 3){//pad zero before zip code
            return inZip = "00"+inZip;
        }
            return inZip;
        
   
    }
    
    
    public static double StripDollarSign(String inPrice){ //strip dollar sign method
 
        String price;
        double priceamount;
        price = inPrice.substring(1);//read the string only after the dollar sign
        
        priceamount = Double.parseDouble(price);
        return priceamount;
        
    }   
}