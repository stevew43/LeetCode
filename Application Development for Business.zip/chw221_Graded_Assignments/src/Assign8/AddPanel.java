/*******************************************************************************
 * Project8, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: December 13, 2019
 * 
 * In this class, the add property information panel is created. There are 
 * various text fields for user to input information. Also, there also includes
 * several drop down menus for users to select options. When user entered all
 * information and click on add button,the program will validate each fields to 
 * see if inputs meet certain requirements. If no error, a window will pop with 
 * the message indicating that the property information has been added, and 
 * property information will be added to the existing property array. If there 
 * is any error, the program will alert the user with the specific error input. 
 * clear button clears all information in every entry. Go back button returns 
 * to the menu.(Previous problems have been fixed)
*******************************************************************************/
package Assign8;



import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JPanel;
import java.awt.event.*;
import javax.swing.*;


public class AddPanel extends JPanel implements ActionListener {
    

    
         String[] StateString = { "","Alabama","Alaska","Arizona","Arkansas",""
                 + "California","Colorado","Connecticut","Delaware","Florida",
                 "Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa",
                 "Kansas","Kentucky","Louisiana","Maine","Maryland",
                 "Massachusetts","Michigan","Minnesota","Mississippi","Missouri"
                 ,"Montana","Nebraska","Nevada","New Hampshire","New Jersey",
                 "New Mexico","New York","North Carolina","North Dakota","Ohio",
                 "Oklahoma","Oregon","Pennsylvania","Rhode Island",
                 "South Carolina","South Dakota","Tennessee","Texas","Utah",
                 "Vermont","Virginia","Washington","West Virginia","Wisconsin"
                 ,"Wyoming"}; //50 states
         
         String[] ProptypeString = { "", "Apartment", "Guest Suite", "House", 
             "Condominium", "Bed and Breakfast" }; //type of properties
         String[] RoomtypeString = { "", "Entire House", "Private Room", 
             "Shared Space"}; //room type
         String[] AccommodationString = { "", "1", "2", "3","4","5","6","7","8"
                 ,"9","10"}; //accommodation number
         String[] BedroomsString = { "","0","1", "2", "3","4","5","6","7","8",
             "9","10"}; //Bedroom number
         String[] BathroomsString = { "", "1", "2", "3","4","5","6","7","8"
                 ,"9","10"}; //Bathroom number
         
        JLabel PropID = new JLabel("Property ID:");  //instructions 
        JTextField PropIDInput = new JTextField(2); //text field 
        JLabel HostID = new JLabel("Host ID:");   //host id
        JTextField HostIDInput = new JTextField(2);
        JLabel PropName = new JLabel("Property name:");   //property name
        JTextField PropNameInput = new JTextField(2);
        JLabel PropSum = new JLabel("Property summary:");   //property summary
        JTextField PropSumInput = new JTextField(2);
        JLabel City = new JLabel("Which city:"); // city 
        JTextField CityInput = new JTextField(2);
        JLabel Zip = new JLabel("Zip code:"); //zip code 
        JTextField ZipInput = new JTextField(2);
        JLabel Price = new JLabel("Price per night:"); //price 
        JTextField PriceInput = new JTextField(2);
        JLabel Security = new JLabel("Security deposit:"); // security deposit
        JTextField SecurityInput = new JTextField(2);
        JLabel Cleaning = new JLabel("Cleaning fee:"); //cleaning fee
        JTextField CleaningInput = new JTextField(2);
         
        JLabel InsState = new JLabel("Choose state:"); //instructions for states
        JLabel InsProptype = new JLabel("Choose property type:");//instructions for property type
        JLabel InsRoomtype = new JLabel("Choose room type:");//instructions
        JLabel InsAccommodation = new JLabel("Choose accommodates:");//instructions
        JLabel InsBed = new JLabel("Choose bedrooms:");//instructions
        JLabel InsBath = new JLabel("Choose bathrooms:");//instructions
        JLabel InsBlank = new JLabel("");
       
        JButton Add = new JButton("Add");  // add, return and clear buttons
        JButton Exit = new JButton("Go Back");
        JButton Clear = new JButton("Clear");
        
         JComboBox StateChoice = new JComboBox(StateString);  //drop down menus for options
         JComboBox ProptypeChoice = new JComboBox(ProptypeString);//drop down
         JComboBox RoomtypeChoice = new JComboBox(RoomtypeString);
         JComboBox AccommodationChoice = new JComboBox(AccommodationString);
         JComboBox BedroomsChoice = new JComboBox(BedroomsString);
         JComboBox BathroomsChoice = new JComboBox(BathroomsString);
        
        
        public AddPanel(){
          
          JPanel bot = new JPanel();// creating a new panel (bottom) only for add, goback, and clear buttons
          setLayout(new GridLayout(8,2)); //setting overall grid layout
          bot.setLayout(new GridLayout(1,3,2,2)); // seetting the new panel (bottom) grid layout
          
          add(PropID);  //adding text filelds and instructions to panel
          add(PropIDInput); 
          add(HostID);
          add(HostIDInput);
          add(PropName);
          add(PropNameInput);
          add(PropSum);
          add(PropSumInput);
          add(City);
          add(CityInput);
          add(Zip);
          add(ZipInput);
          add(Price);
          add(PriceInput);
          add(Security);
          add(SecurityInput);
          add(Cleaning);
          add(CleaningInput);
         
          
          add(InsState); // adding drop down menus and instructions to panel
          add(StateChoice);
          add(InsProptype);
          add(ProptypeChoice);
          add(InsRoomtype);
          add(RoomtypeChoice);
          add(InsAccommodation);
          add(AccommodationChoice);
          add(InsBed);
          add(BedroomsChoice);
          add(InsBath);
          add(BathroomsChoice);  
          add(InsBlank);
            
          bot.add(Add);  // adding three buttons to the bottom panel
          bot.add(Clear);
          bot.add(Exit);
          
          
         add(bot,BorderLayout.SOUTH); //setting south panel
         Add.addActionListener(this);
         Exit.addActionListener(this);
         Clear.addActionListener(this);
                            
        }
    
        public void actionPerformed(ActionEvent e){
            
                               
 
            int errorcount =0;//count for when there is an input error
            
            
            String op = e.getActionCommand(); //get action
            String Propvalue,Hostvalue = null;//the property id and hostidvalue of input get from users
            String PropNamevalue = null,PropSumvalue=null; //the property name and property summary value of input get from users
            String Cityvalue = null,Zipvalue = null,Pricevalue = null;//the city, zip code and price value of input get from users
            String Securityvalue = null,Cleaningvalue = null,Statevalue=null;//the security deposit, cleaning fee and state value of input get from users
            String Proptypevalue=null,Roomtypevalue=null;//the property type and room type value of input get from users
            String Accommodationvalue,Bedroomvalue, Bathroomvalue; //the accommodates, bedroom and bathroom nuber value of input get from users
            
            double Pricevalue1=0; //variable used to store price string parsed into double 
            double Securityvalue1 =0; //variable used to store security deposit string parsed into double 
            double Cleaningvalue1 =0;//variable used to store cleaning fee string parsed into double  
            int Propvalue1 =0;//variable used to store property id string parsed into int
            int Hostvalue1 =0;//variable used to store host id string parsed into int
            int Accommodationvalue1=0;//variable used to store accommodates string parsed into int
            int Bathroomvalue1 =0; //variable used to store bathroom number string parsed into int
            int Bedroomvalue1 = 0;//variable used to store bedroom number string parsed into int
       
       
       if(op.equals("Clear")){ // when click on clear 
           
           clear();//calling clear method
           
       }
   
       if(op.equals("Add")){ //when click on add button
           Propvalue=PropIDInput.getText();  //getting value from user input
           Hostvalue= HostIDInput.getText();//getting value from user input
           PropNamevalue=PropNameInput.getText(); //getting value from user input
           PropSumvalue=PropSumInput.getText();
           Cityvalue=CityInput.getText();
           Zipvalue=ZipInput.getText();
           Pricevalue=PriceInput.getText();
           Securityvalue=SecurityInput.getText();
           Cleaningvalue= CleaningInput.getText();
           Statevalue = StateChoice.getSelectedItem().toString();//getting value from user selection and convert it into string
           Proptypevalue = ProptypeChoice.getSelectedItem().toString(); //getting value from user selection and convert it into string
           Roomtypevalue = RoomtypeChoice.getSelectedItem().toString();      
           Accommodationvalue =AccommodationChoice.getSelectedItem().toString();
           Bedroomvalue =BedroomsChoice.getSelectedItem().toString();
           Bathroomvalue =BathroomsChoice. getSelectedItem().toString();
           
          
         //property validation  
         if(Propvalue.equals("")) {
              JOptionPane.showMessageDialog( null, "Property ID cannot be "
                      + "blank."); // pop up message window
              
              errorcount++;
              
          }      
         else if(!Propvalue.equals("")) {//when user type in something
          try {
          Propvalue1 = Integer.parseInt(Propvalue); //parse value into integer
           
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid number for Property ID."); //error message pop up
            
            errorcount++;//input error increases
            
         }    
        }  
           
  
         
         
         
         //host validation
        
          if(Hostvalue.equals("")) { //when empty
              JOptionPane.showMessageDialog( null, "Host ID cannot be blank."); // pop up message window
              
              errorcount++;//input error increases
              
          }    
           if(!Hostvalue.equals("")) {//when type in something
             try {
          Hostvalue1 = Integer.parseInt(Hostvalue); //parse value into integer
           
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid number for Host ID."); //error message pop up
          
            errorcount++;//input error increases
            
         } 
                      
              if(Hostvalue1 <1){//if less than one 
              JOptionPane.showMessageDialog( null, "Host ID must be at "
                      + "least 1."); // pop up message window
              
              errorcount++;//input error increases
             
           }   
        }  
          
                 
                       
         //Property name validation    
                  
                  
          if(PropNamevalue.equals("")) {
              JOptionPane.showMessageDialog( null, "Property name cannot be "
                      + "blank."); // pop up message window
             
              errorcount++;//input error increases
          }             
          
          
          //City validation
          if(Cityvalue.equals("")) {
              JOptionPane.showMessageDialog( null, "City cannot be blank."); // pop up message window
             
              errorcount++;//input error increases
          }    
          
          
       
          
          //zip code validation
           if(Zipvalue.equals("")) {//when empty
              JOptionPane.showMessageDialog( null, "Zip code cannot be blank."); // pop up message window
              
              errorcount++;//input error increases
          }         
           if(!Zipvalue.equals("")){//not empty
               
          try {
           Integer.parseInt(Zipvalue); //parse value into integer
           
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid number for Zip code."); //error message pop up
          
            errorcount++;
            
         } 
             if (Zipvalue.length()!=5){
                JOptionPane.showMessageDialog( null, "Zip code must be "
                        + "5 digits."); //error message pop up
               
                errorcount++;
            }   
         }

           
    

        //price validation
           if(Pricevalue.equals("")) {
              JOptionPane.showMessageDialog( null, "Price cannot be blank."); // pop up message window
              
              errorcount++;
              
          } 
           
           if(!Pricevalue.equals("")){
          try {
          Pricevalue1 = Double.parseDouble(Pricevalue); //parse value into integer
           
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid number for price."); //error message pop up
            
            errorcount++;
            
         }    
          
          
           if(Pricevalue1 <1) {//when price less than 1
              JOptionPane.showMessageDialog( null, "Price must be at least "
                      + "1."); // pop up message window
              
              errorcount++;
               }
           
           if(Pricevalue1 >30000) {//when price is too high
              JOptionPane.showMessageDialog( null, "Your price per night "
                      + "is too high."); // pop up message window
              
              errorcount++;
               }           
          
         }
           
  
           
           //accommodates validation
           
            if(Accommodationvalue.equals("")) {
              JOptionPane.showMessageDialog( null, "Accommodates cannot be"
                      + " blank."); // pop up message window
              
              errorcount++;
              
          } 
            if(!Accommodationvalue.equals("")){
                Accommodationvalue1 = Integer.parseInt(Accommodationvalue);
                
            if(Accommodationvalue1 <1) {

              
              JOptionPane.showMessageDialog( null, "Accommodates must be "
                      + "at least 1."); // pop up message window
              
              errorcount++;
          } 
            }
            
            

            
          //bedroom validation   
          if(Bedroomvalue.equals("")) {
              JOptionPane.showMessageDialog( null, "Bedroom cannot be blank."); // pop up message window
              
              errorcount++;
      
          } 
              if(!Bedroomvalue.equals("")) {
                  
             Bedroomvalue1 = Integer.parseInt(Bedroomvalue);
             if(Bedroomvalue1 <0) {
              
              JOptionPane.showMessageDialog( null, "Bedroom must be greater "
                      + "than 0."); // pop up message window
              
              errorcount++;
          } 
              
              }
              
              
                    
           //bathroom validation
            if(Bathroomvalue.equals("")) {
              JOptionPane.showMessageDialog( null, "Bathroom cannot be blank."); // pop up message window
            
              errorcount++;
              
          } 
            if(!Bathroomvalue.equals("")){
                Bathroomvalue1 = Integer.parseInt(Bathroomvalue);
            if(Bathroomvalue1 <0) {
              
              JOptionPane.showMessageDialog( null, "Bathroom must be at least "
                      + "0."); // pop up message window
            
              errorcount++;
          } 
           
            }
            
  
      
         //security deposit validation      
         if(Securityvalue.equals(""))  {
             Securityvalue1=0;// no security deposit
         }
         
         if (!Securityvalue.equals("")){
             try {
          Securityvalue1 = Double.parseDouble(Securityvalue); //parse value into integer
           
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid number for security deposit."); //error message pop up
           
            errorcount++;
           
         }
             if(Securityvalue1 <0) {
              
              JOptionPane.showMessageDialog( null, "Security deposit must be "
                      + "at least 0."); // pop up message window
              
              errorcount++;
          }   
                if(Securityvalue1 >30000) {//when amount is too high
              JOptionPane.showMessageDialog( null, "Your security deposit "
                      + "is too high."); // pop up message window
              
              errorcount++;
               }  
         }
        
        
         
         
         //cleaning fee validation
         if(Cleaningvalue.equals(""))  {
             Cleaningvalue1=0;
         }
         
         
         if (!Cleaningvalue.equals("")){  
          try {
          Cleaningvalue1 = Double.parseDouble(Cleaningvalue); //parse value into integer
           
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid number for cleaning fee."); //error message pop up
            
            errorcount++;
            
         }   
            if(Cleaningvalue1 <0) {
              
              JOptionPane.showMessageDialog( null, "Cleaning fee must be at "
                      + "least 0."); // pop up message window
            
              errorcount++;
          }   
               if(Cleaningvalue1 >30000) {//when amount is too high
              JOptionPane.showMessageDialog( null, "Your cleaning fee is "
                      + "too high."); // pop up message window
              
              errorcount++;
               }  
            
         }  
         
  
            
         

          
          
              if (errorcount==0){ //the condition when there is no any error in all user input, then all information can be added to the object array
                  
                    //first adding the bed room count, input from user
               
               if (Bedroomvalue1 == 0){
                  MakeObjects.zerob++; //bedroom number increases
              }
              if (Bedroomvalue1 == 1){
                  MakeObjects.oneb++;
              }
               if (Bedroomvalue1  == 2){
                  MakeObjects.twob++;
              }
                if (Bedroomvalue1 == 3){
                  MakeObjects.threeb++;
              }
                if (Bedroomvalue1 == 4){
                  MakeObjects.fourb++;
              }
                if (Bedroomvalue1 >= 5){
                  MakeObjects.fiveb++;
              }
               
      
                
                
                
       MakeObjects.prop++; //increase the property object once there is a property being added

        MakeObjects.Property [(MakeObjects.prop)-1]= new AirbnbProperty    //-1 here (because after the array is created in MakeObjects, the prop has a ++ at the end but it does not represent the true array spot here(otherwise its going to be a null spot))
             (Propvalue1,Hostvalue1,PropNamevalue,PropSumvalue,Cityvalue,
              Statevalue,Zipvalue,Proptypevalue,Roomtypevalue,
              Accommodationvalue1, Bathroomvalue1,Bedroomvalue1,
              Pricevalue1,Securityvalue1,Cleaningvalue1) ;  //the object array which will be added to a new spot in the original array
        

              JOptionPane.showMessageDialog( null, "I added your property to "
                   + "Airbnb!"); // pop up message window
  
                    clear();//calling clear method

           }
 
       }
       
             
         if(op.equals("Go Back")){
             
           clear();//calling clear method
           
         MainWindow.mainGUI.setVisible(true); //show main window
         MainWindow.addGUI.setVisible(false);//hide addgui window
       }
} 
        
        
         public void clear(){//fixed from assign7, added a clear method here
             
           PropIDInput.setText(""); //set all text fields to blank
           HostIDInput.setText("");
           PropNameInput.setText("");
           PropSumInput.setText("");
           CityInput.setText("");
           ZipInput.setText("");
           PriceInput.setText("");
           SecurityInput.setText("");
           CleaningInput.setText(""); 
           StateChoice.setSelectedItem("");
           ProptypeChoice.setSelectedItem("");
           RoomtypeChoice.setSelectedItem("");
           AccommodationChoice.setSelectedItem("");
           BedroomsChoice.setSelectedItem("");
           BathroomsChoice.setSelectedItem("");
         }
}
