/*******************************************************************************
 * Project8, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: December 13, 2019
 * 
 * The blueprint class of AirbnbProperty which includes all the instance 
 * variables for property entries which is the data fields from number 0 to 3, 
 * and 11 to 24 in the table constructor methods, get and set methods, and 
 * toString methods with format, at the end of the class. There is another 
 * constructor added to the class, which is used for added objects to property 
 * array with the input from the AddPanel class.(Previous problems have been 
 * fixed)
*******************************************************************************/
package Assign8;

public class AirbnbProperty { 
    private int id; //property id //fixed from assign6, added comment
    private String name; //property name
    private String summary;//property summary 
    private String neighborhood;//neighborhood info
    private String City;//located city
    private String State;//located state
    private String Zipcode;//zip code info
    private String Property_type;//property type
    private String Room_type;//room type
    private int accommodates;// accomodation
    private int Bathrooms;//bathrooms number
    private int Bedrooms;//bedroom number
    private double Price;//price amount
    private double securitydeposit;//security deposit
    private double Cleaning;//cleaning price
    private int Review;//review information
    private int Review_scores_rating;//review information
    
    
    public AirbnbProperty(int inid,String inname,String insummary,
            String inneighborhood,String inCity,String inState,String inZipcode,
            String inProperty_type,String inRoom_type,int inaccommodates,int 
                    inBathrooms,int inBedrooms,double inPrice,double 
                            insecuritydeposit,double inCleaning,int inReview, 
                            int inReview_scores_rating){//constructor containing all instance variables
        id = inid;
        name = inname;
        summary = insummary;
        neighborhood = inneighborhood;
        City = inCity;
        State = inState;
        Zipcode = inZipcode;
        Property_type = inProperty_type;
        Room_type = inRoom_type;
        accommodates = inaccommodates;
        Bathrooms = inBathrooms;
        Bedrooms = inBedrooms;
        Price = inPrice;
        securitydeposit = insecuritydeposit;
        Cleaning = inCleaning;
        Review = inReview;
        Review_scores_rating = inReview_scores_rating;
        
    }
    
    
    
    public AirbnbProperty(int inid,int inhost_id,String inname,String insummary,
           String inCity,String inState,String inZipcode,
            String inProperty_type,String inRoom_type,int inaccommodates,int 
                    inBathrooms,int inBedrooms,double inPrice,double 
                            insecuritydeposit,double inCleaning){ //2nd constructor which will be used for AddPanel inputs
            
        id = inid;
        AirbnbHost.host_id = inhost_id;//the hostid in airbnb host class
        name = inname;
        summary = insummary;
        neighborhood = "";//there's no input for neighborhood information 
        City = inCity;
        State = inState;
        Zipcode = inZipcode;
        Property_type = inProperty_type;
        Room_type = inRoom_type;
        accommodates = inaccommodates;
        Bathrooms = inBathrooms;
        Bedrooms = inBedrooms;
        Price = inPrice;
        securitydeposit = insecuritydeposit;
        Cleaning = inCleaning;
        Review = 0; //there's no input for review
        Review_scores_rating = 0;//no input for ratings
 
        }
    
    

    
    public int getid(){  //get methods starts from here
        return id;
    }
    
    public String getname(){
        return name;
    }

    public String getsummary(){
        return summary;
    }

    
    public String getneighborhood(){
        return neighborhood;
    }

    public String getCity(){
        return City;
    }

    public String getState(){
        return State;
    }

    public String getZipcode(){
        return Zipcode;
    }

    public String getProperty_type(){
        return Property_type;
    }    
    
    public String getRoom_type(){
        return Room_type;
    }

    public int getaccommodates(){
        return accommodates;
    }

    public int getBathrooms(){
        return Bathrooms;
    }

    public int getBedrooms(){
        return Bedrooms;
    }

    public double getPrice(){
        return Price;
    }

    public double getsecuritydeposit(){
        return securitydeposit;
    }

    public double getCleaning(){
        return Cleaning;
    }    

    public int getReview(){
        return Review;
    }    

    public int getReview_scores_rating(){
        return Review_scores_rating;
    }    

    
    
    
    public void setid(int theid){ //set methods start from here
        id = theid;
        }
    
    public void setname(String thename){
        name = thename;
        }
    
    public void setsummary(String thesummary){
        summary = thesummary;
        }

    
    public void setneighborhood(String theneighborhood){
        neighborhood = theneighborhood;
        }
    public void setCity(String theCity){
        City = theCity;
        }
    public void setState(String theState){
        State = theState;
        }
    public void setZipcode(String theZipcode){
        Zipcode = theZipcode;
        }
    public void setProperty_type(String theProperty_type){
        Property_type = theProperty_type;
        }
    public void setRoom_type(String theRoom_type){
        Room_type = theRoom_type;
        }
    public void setaccommodates(int theaccomodates){
        accommodates = theaccomodates;
        }
    public void setBathrooms(int theBathrooms){
        Bathrooms = theBathrooms;
        }
    public void setBedrooms(int theBedrooms){
        Bedrooms = theBedrooms;
        }
    public void setPrice(double thePrice){
        Price = thePrice;
        }
    public void setsecuritydeposit(double thesecuritydeposit){
        securitydeposit = thesecuritydeposit;
        }
    public void setCleaning(int theCleaning){
        Cleaning = theCleaning;
        }
    public void setReview(int theReview){
        Review = theReview;
        }
    public void setReview_scores_ratings(int theReview_scores_rating){
        Review_scores_rating = theReview_scores_rating;
        }    
    
   //
    
 
    public String toString(){ // toString method
        String result;
        result = "Property ID: "+ id;
        result += "\nProperty name: "+name;
        result +="\nNeighborhood: "+ neighborhood;
        result +="\nCity: "+ City;
        result +="\nState: "+ State;
        result +="\nZip code: "+ Zipcode;
        result +="\nAvailable accommodates: "+ accommodates;
        result +="\nNumber of bathrooms: "+ Bathrooms;
        result +="\nNumber of bedrooms: "+ Bedrooms;
        result +="\nPrice: $"+ String.format("%,.2f", Price); //price format
        result +="\nNumber of reviews: "+ Review;
        result +="\nRatings: "+ Review_scores_rating;
        
        return result;    
    }
    
    
}
