/*******************************************************************************
 * Project2, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: September 3, 2019
 * 
 * In this program, you are to calculate your gross pay (pay before taxes) and 
 * use the given tax rates to display the dollar amount for each individual tax
 * and net pay).The output must be printed in a user friendly format, with the 
 * dollar amounts aligned vertically Every calculation must be saved to a 
 * variable, and not calculated in the print statements.
*******************************************************************************/
package Assign2;


public class Paycheck 
{ //begin class
    public static void main(String[] args)
    {
        
    double hrpay = 15; // hour pay
    int hr = 40; // work hour
    
    double grosspay = hrpay * hr;
    double fedtax = 0.083 * grosspay; //federal tax
    double statetax = 0.0307 * grosspay;
    double ss = 0.062 * grosspay; //social security
    double medicare = 0.0145 * grosspay;
    
    double sum; // total tax
    sum = fedtax + statetax + ss + medicare; //total tax amount
    
    double netpay = grosspay - sum; //net pay amount
    
    System.out.println("PAYCHECK");
    
    System.out.println("");
    
    System.out.print("Gross Pay:");
    System.out.print("\t\t");
    System.out.printf("$%1.2f",grosspay);
    System.out.println("");
    System.out.println("");
   
    System.out.print("Federal Tax:");
    System.out.print("\t\t");
    System.out.printf("$ %1.2f",fedtax);
    System.out.println("");
    
    System.out.print("State Tax:");
    System.out.print("\t\t");
    System.out.printf("$ %1.2f",statetax);
    System.out.println("");
    
    System.out.print("Social Security:");
    System.out.print("\t");
    System.out.printf("$ %1.2f",ss);
    System.out.println("");
    
    System.out.print("Medicare:");
    System.out.print("\t\t");
    System.out.printf("$  %1.2f",medicare);
    System.out.println("");
    System.out.println("");
   
    
    System.out.print("Total Taxes:");
    System.out.print("\t\t");
    System.out.printf("$%1.2f",sum);
    System.out.println("");
    
    System.out.print("Net Pay:");
    System.out.print("\t\t");
    System.out.printf("$%1.2f",netpay);
    
    
      
    }
    
} //end class
