/*******************************************************************************
 * Project2, BIS 335, Business Application Development, Fall 2019
 * 
 * Author: Steven Weng
 * Date: September 3, 2019
 * 
 * In this program, the user is comparing and iPhone XS to a Samsung Galaxy S10 
 * There are two options: a 12 month payment plan and a 24 month payment plan
 * In order to calculate the cost of each phone for each payment plan, the user
 * should have the prices of each phone (iPhone XS is $999 and Samsung Galaxy 
 * S10 is $899), and the down payment will be 20% of the retail price.
*******************************************************************************/


package Assign2;


public class PhonePayment 
{ //begin class
 public static void main(String[] args) 
    {
    
    String iphone = "iPhone XS";
    String samsung = "Samsung Galaxy S10";
    
    double PI = 999; //iphone inital price
    double PS = 899; //samsung initial price
    
    double downpayment = 0.2;
    
    double CFI = PI*(1-downpayment); //iphone cost after downpayment
    double CFS = PS*(1-downpayment); //samsung cost after downpayment
    
    double P12I = CFI/12; //iphone 12 months plan cost
    double P12S = CFS/12; //samsung 12 months plan cost
    
    double P24I = CFI/24; //iphone 24 months plan cost
    double P24S = CFS/24; //samsung 24 months plan cost
    
    
    System.out.println("12 Month Payment Plan:");
    System.out.println("");
    System.out.print(iphone);
    System.out.print("\t\t");
    System.out.printf("$ %1.2f", P12I);
    System.out.println("");
    System.out.print(samsung);
    System.out.print("\t");
    System.out.printf("$ %1.2f", P12S);
    
    System.out.println("");
    System.out.println("");
    
    System.out.println("24 Month Payment Plan:");
    System.out.println("");
    System.out.print(iphone);
    System.out.print("\t\t");
    System.out.printf("$ %1.2f", P24I);
    System.out.println("");
    System.out.print(samsung);
    System.out.print("\t");
    System.out.printf("$ %1.2f", P24S);
    
    }
       
     
} //end class

    

