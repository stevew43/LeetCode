/*******************************************************************************
 * Project3, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: September 13, 2019
 * 
 * In this program, you are to create a username following the rules set forth 
 * here. Ask the user for his/her first, middle, and last name, and save each 
 * one to a variable. The first three characters of the username is the first 
 * letter of the first name, the first letter of the middle name, and the first 
 * letter of the last name. The next part of the user name is the number of 
 * characters total in the entire user name.
*******************************************************************************/
package Assign3;


public class Username { //begin class
   public static void main(String[] args)
    {
       String firstname,middlename,lastname;
       
       
       System.out.print("Please enter your first name: "); 
       firstname = TextIO.getln();  //1st name userinput
       
       
       System.out.print("\nPlease enter your middle name: "); 
       middlename = TextIO.getln();
       
       
       
       System.out.print("\nPlease enter your last name: "); 
       lastname = TextIO.getln(); //last name user input
       
       
       int fnlength, mnlength, lnlength; //length for each input
       fnlength = firstname.length();
       mnlength = middlename.length();
       lnlength = lastname.length();
       int totallength = fnlength + mnlength + lnlength; //entire length
       
       
       char firstnamechar, middlenamechar, lastnamechar;
       firstnamechar = firstname.charAt(0); //convert string into initial letter
       middlenamechar = middlename.charAt(0); //convert string into initial letter
       lastnamechar = lastname.charAt(0); //convert string into initial letter
     
      
       System.out.print("\nYour username is: ");
       
       System.out.print(firstnamechar); //print out intial letter converted from string
       System.out.print(middlenamechar); //print out intial letter converted from string
       System.out.print(lastnamechar); //print out intial letter converted from string
       System.out.print(totallength); //print out intial letter converted from string 
       
       System.out.println("");
       
       
    } 
} // end class
