/*******************************************************************************
 * Project3, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: September 13, 2019
 * 
 * In this program, it is a modified paycheck program. With the similar format
 * of the previous, but added user input of work hours and wage. The exceed 
 * amount of time (greater than 40 hrs) will be counted as overtime pay.
*******************************************************************************/
package Assign3;

public class PaycheckBetter { //begin class
    public static void main(String[] args)
    {
    double hrpay; // hour pay
    double hr; // work hour
    
    
    System.out.println("How many hours did you work this week? ");
    hr = TextIO.getlnDouble(); //user input of work hours
    System.out.println("What is your hourly wage? ");
    hrpay = TextIO.getlnDouble(); // user input of wage
   
    double grosspay;
    
    double nootgp = hr*hrpay; //not overtime grosspay
    double otpay = (hr-40)*hrpay*1.5; //overtime extra pay
    double otgp = 40*hrpay+(hr-40)*hrpay*1.5; //overtime grosspay calculation
    grosspay = (hr > 40)? otgp : nootgp;// grosspay overtime condition
    
    double fedtax = 0.083 * grosspay; //federal tax
    double statetax = 0.0307 * grosspay; //state tax
    double ss = 0.062 * grosspay; //social security
    double medicare = 0.0145 * grosspay; //medicare
    
    double sum; // total tax
    sum = fedtax + statetax + ss + medicare; //total tax amount
    double netpay = grosspay - sum; //net pay amount
    
   
    
    
    System.out.println("");                                 //printing out
    System.out.println("PAYCHECK");
    
    System.out.println("");
    System.out.print("Regular Wages:");
    System.out.print("\t\t");
    double regularwage;
    regularwage = (hr > 40) ? 40*hrpay : nootgp; // the result of whether it is overtime or not
    System.out.printf("$%,8.2f",regularwage);
  
   
    System.out.println("");
    System.out.print("Overtime Wages:");
    System.out.print("\t\t");
    double overtimepay;
    overtimepay = (hr > 40) ? otpay : 0; // the result of whether it is overtime or not
    System.out.printf("$%,8.2f",overtimepay);
    System.out.println("");

    
    System.out.print("Gross Pay:");
    System.out.print("\t\t");
    System.out.printf("$%,8.2f",grosspay);
    System.out.println("");
    System.out.println("");
   
    System.out.print("Federal Tax:");
    System.out.print("\t\t");
    System.out.printf("$%,8.2f",fedtax);
    System.out.println("");
    
    System.out.print("State Tax:");
    System.out.print("\t\t");
    System.out.printf("$%,8.2f",statetax);
    System.out.println("");
    
    System.out.print("Social Security:");
    System.out.print("\t");
    System.out.printf("$%,8.2f",ss);
    System.out.println("");
    
    System.out.print("Medicare:");
    System.out.print("\t\t");
    System.out.printf("$%,8.2f",medicare);
    System.out.println("");
    System.out.println("");
   
    
    System.out.print("Total Taxes:");
    System.out.print("\t\t");
    System.out.printf("$%,8.2f",sum);
    System.out.println("");
    
    System.out.print("Net Pay:");
    System.out.print("\t\t");
    System.out.printf("$%,8.2f",netpay);
    
    
    System.out.println("");  
    } // end class
}
