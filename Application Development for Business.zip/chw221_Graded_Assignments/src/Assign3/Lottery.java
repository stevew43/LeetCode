
/*******************************************************************************
 * Project3, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: September 13, 2019
 * 
 * In this program, you are to write code that will simulate a scratch off 
 * lottery ticket. There is no user input for this program. Your code will 
 * generate 3 winning numbers, and then simulate a user “scratching off” 9 spots
 * on a lottery ticket to see if the numbers scratched off match the three 
 * winning numbers.
*******************************************************************************/
package Assign3;


public class Lottery {
    public static void main(String[] args)
    {
     System.out.println("Welcome to the scratch off lottery game.");
     System.out.println("");
     System.out.println("Here are the winning number that you need to match:");   
     
     
     double number19 = Math.random()*8+2;//the win number from 1-9
     double number1023 = Math.random()*13+11;//the win number from 10-23
     double number2430 = Math.random()*6+25;//the win number from 24-30
     int N19 = (int)number19; // the win number 1-9 converted into int
     int N1023 = (int)number1023; //the win number 1-9 converted into int
     int N2430 = (int)number2430; //the win number 1-9 converted into int
     
     System.out.print("     ");
     System.out.println(N19); //printing out the win number in integer
     System.out.print("     ");
     System.out.println(N1023);   
     System.out.print("     ");
     System.out.println(N2430);   
     
     
     
     
      
     double usernumber191 = Math.random()*8+1; //the user number from 1-9  //the 1 at the end of usernumber means 1st try
     double usernumber192 = Math.random()*8+1; //the user number from 1-9  //the 2 at the end of usernumber means 2nd try
     double usernumber193 = Math.random()*8+1; //the user number from 1-9  //the 3 at the end means of usernumber 3rd try
     double usernumber10231 = Math.random()*13+10; //the user number from 10-23  //the 1 at the end of usernumber means 1st try
     double usernumber10232 = Math.random()*13+10; //the user number from 10-23  //the 2 at the end of usernumber means 2nd try
     double usernumber10233 = Math.random()*13+10; //the user number from 10-23  //the 3 at the end of usernumber means 3rd try
     double usernumber24301 = Math.random()*6+24; //the user number from 24-30   //the 1 at the end of usernumber means 1st try
     double usernumber24302 = Math.random()*6+24; //the user number from 24-30   //the 2 at the end of usernumber means 2nd try
     double usernumber24303 = Math.random()*6+24; //the user number from 24-30   //the 3 at the end of usernumber means 3rd try
     
     
     int UN191 = (int)usernumber191; // user number 1-9 converted into int     //the 1 at the end of UN means 1st try //UN means usernumber
     int UN192 = (int)usernumber192; // user number 1-9 converted into int     //the 2...
     int UN193 = (int)usernumber193; // user number 1-9 converted into int     //the 3...
     int UN10231 = (int)usernumber10231; // user number 10-23 converted into int
     int UN10232 = (int)usernumber10232; // user number 10-23 converted into int
     int UN10233 = (int)usernumber10233; // user number 10-23 converted into int
     int UN24301 = (int)usernumber24301;// user number 24-30 converted into int
     int UN24302 = (int)usernumber24302;// user number 24-30 converted into int
     int UN24303 = (int)usernumber24303;// user number 24-30 converted into int
    
     
     
     
     
     String result1sttry;                                                      // 1st try: conditions and print out
     result1sttry = (UN191 == N19) ? "1st try: Scratching off....got number "+
     UN191+"....You win $" + UN191*UN191 +"!" :  "1st try: Scratching off"     
     + "....got number " + UN191+"....Sorry, you lost.";
     System.out.println("\n----------------------------");  
     System.out.print(result1sttry);   
     
     String result2ndtry;                                                      // 2nd try: conditions and print out
     result2ndtry = (UN192 == N19) ? "2nd try: Scratching off....got number "+
     UN192+"....You win $" + UN192*UN192 +"!" :  "2nd try: Scratching off"
     + "....got number " + UN192+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result2ndtry); 
     
     String result3rdtry;                                                      // 3rd try: conditions and print out
     result3rdtry = (UN193 == N19) ? "3rd try: Scratching off....got number "+
     UN193+"....You win $" + UN193*UN193 +"!" :  "3rd try: Scratching off...."
     + "got number " + UN193+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result3rdtry); 
     
     String result4thtry;                                                      // 4th try: conditions and print out
     result4thtry = (UN10231 == N1023) ? "4th try: Scratching off....got number"
     + UN10231+"....You win $" + UN10231*UN10231 +"!":"4th try: Scratching off"
     + "....got number " + UN10231+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result4thtry); 
     
     String result5thtry;                                                      // 5th try: conditions and print out
     result5thtry = (UN10232 == N1023) ? "5th try: Scratching off...got number "
     + UN10232+"....You win $" + UN10232*UN10232 +"!" :  "5th try: Scratching "
     + "off....got number " + UN10232+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result5thtry); 
     
     String result6thtry;                                                      // 6th try: conditions and print out
     result6thtry = (UN10233 == N1023) ? "6th try: Scratching off...."
     + "got number "+ UN10233+"....You win $" + UN10233*UN10233 +"!" :  
     "6th try: Scratching off....got number " + UN10233+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result6thtry);
     
     String result7thtry;                                                      // 7th try: conditions and print out
     result7thtry = (UN24301 == N2430) ? "7th try: Scratching off...."
     + "got number "+ UN24301+"....You win $" + UN24301*UN24301 +"!" :  
     "7th try: Scratching off....got number " + UN24301+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result7thtry);
     
     String result8thtry;                                                      // 8th try: conditions and print out
     result8thtry = (UN24302 == N2430) ? "8th try: Scratching off...."
     + "got number "+ UN24302+"....You win $" + UN24302*UN24302 +"!" :  
     "8th try: Scratching off....got number " + UN24302+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result8thtry);
     
     String result9thtry;                                                      // 9th try: conditions and print out
     result9thtry = (UN24303 == N2430) ? "9th try: Scratching off...."
     + "got number "+ UN24303+"....You win $" + UN24303*UN24303 +"!" :  
     "9th try: Scratching off....got number " + UN24303+"....Sorry, you lost.";
     System.out.println(""); 
     System.out.print(result9thtry);
     
     System.out.println("");
    }
}
