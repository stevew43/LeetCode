/*
* Assignment 1, BIS 335, Business Application Development, Fall 2019 *
* Author: Steven Weng * Date: August 27, 2019 *
* This program writes about a description on stuent information
* and course goals, mainly using println statements.
 */
package Assign1;


public class AboutMe 
{

 
    public static void main(String[] args) 
    {
         System.out.println("Name:Chengming(Steven) Weng");
         System.out.println("");
         System.out.println("Hometown:Shanghai,China");
         System.out.println("");
         System.out.println("Why are you taking BIS 335?");
         System.out.println("   It is requied for my major and I wanted to see how Java can be implemented into information system.");
         System.out.println("");
         System.out.println("What is your biggest concern?");
         System.out.println("   The course may be fast paced and I cannot always keep up.");
          System.out.println("");
           System.out.println("What do you hope to do after graduation?");
            System.out.println("   Successfully get employed in my related field of study.");
    }
    
}
