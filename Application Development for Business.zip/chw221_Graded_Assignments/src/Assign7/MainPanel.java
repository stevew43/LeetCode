/*******************************************************************************
 * Project7, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 25, 2019
 * 
 * This is the main panel of the program which consists of four buttons, 
 * Property graph, Search property, Add your own, and Exit. A welcome message 
 * and instructions are also included at the top. When click on certain button,
 * it will make the according panel visible, meanwhile set the main panel 
 * invisible to the user. 
*******************************************************************************/
package Assign7;


import javax.swing.JPanel;
import java.awt.event.*;
import javax.swing.*;




public class MainPanel extends JPanel implements ActionListener {
        JLabel Welcome = new JLabel("Welcome! For Airbnb properties you can:"); //welcome and instructions message
        JButton GraphButton = new JButton ("Show property graph"); //graph 
        JButton SearchButton = new JButton ("Search property");//search function
        JButton AddButton = new JButton ("Add your own");//add property
        JButton ExitButton = new JButton ("Exit");//exit button
        

        
      public MainPanel(){
          
         setLayout(null); //free layout
         setBorder( BorderFactory.createEtchedBorder() ); 
         add(Welcome);  //adding buttons
         Welcome.setBounds(95,20,300,30);//setting bounds for buttons
         add(GraphButton);
         GraphButton.setBounds(80,60,250,30);
         add(SearchButton);
         SearchButton.setBounds(80,100,250,30);
         add(AddButton);  
         AddButton.setBounds(80,140,250,30);
         add(ExitButton);
         ExitButton.setBounds(80,180,250,30);
         
         GraphButton.addActionListener(this);//adding action listener
         SearchButton.addActionListener(this);
         AddButton.addActionListener(this);
         ExitButton.addActionListener(this);
      }
      
      
      
 public void actionPerformed(ActionEvent e){
    String op = e.getActionCommand();//get user actions
    
    if(op.equals("Show property graph")){
         MainWindow.mainGUI.setVisible(false); //hide maingui
         MainWindow.graphGUI.setVisible(true);//show graph
    }
    else if(op.equals("Search property")){
         MainWindow.mainGUI.setVisible(false);//hide maingui
         MainWindow.searchGUI.setVisible(true);//show search window
    }
    
    else if(op.equals("Add your own")){
         MainWindow.mainGUI.setVisible(false);//hide maingui
         MainWindow.addGUI.setVisible(true);//show add window
    }
    
    else{
    System.exit(0);    //exit the window
    }
    
}     
      
}


