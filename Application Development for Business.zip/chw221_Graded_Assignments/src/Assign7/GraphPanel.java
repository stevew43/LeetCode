/*******************************************************************************
 * Project7, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 25, 2019
 * 
 * In this class, the graph panel is created with a distribution of different
 * room types and represented with different colors in a pie chart. There are 
 * several labels beside the graph, to indicate the numbers and percentage used 
 * for each room type. A description message and an return button are included 
 * in the panel. When user clicks on the Go Back button, it takes the user back
 * to the main window.
*******************************************************************************/
package Assign7;



import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


    
    public class GraphPanel extends JPanel implements ActionListener{
       
        
    JLabel Instructions = new JLabel ("Pie chart for property room types"); //welcome message
   
    JButton ExitButton = new JButton ("Go back"); //return button
    PaintingSurface graphDisplay = new PaintingSurface();   //creating a new graph object
      
       public GraphPanel(){
         
           setLayout(null); //free layout
           setBorder( BorderFactory.createEtchedBorder() ); 

           

          add(graphDisplay); //adding the graph object on to the display
          graphDisplay.setBounds(20,100,600,600);
          
           add (Instructions);//adding instructions button
           add(ExitButton); //adding exit button
             
           ExitButton.addActionListener(this);//adding action listener
           
           ExitButton.setBounds(410, 100, 120, 30);
           Instructions.setBounds(130,50, 300, 30);
           
       }
        
   
    public void actionPerformed(ActionEvent e){
        
    String op = e.getActionCommand();
        if(op.equals("Go back")){
         MainWindow.mainGUI.setVisible(true); //show maingui
         MainWindow.graphGUI.setVisible(false);  //hide graph window


    }

}    
    

    private class PaintingSurface extends JPanel {
        

        public void paintComponent(Graphics g) {
            int zerobedrooms, onebedrooms,twobedrooms,threebedrooms,fourbedrooms
                    ,fiveandmorebedrooms, total,zeroangle,oneangle,twoangle,
                    threeangle,fourangle,fiveandmoreangle,totalangleused,
                    lastwedge;
            
            super.paintComponent(g);

            
            zerobedrooms = 10; //type of bedroom and numbers
            onebedrooms = 26;
            twobedrooms = 13;
            threebedrooms = 45;
            fourbedrooms = 34;
            fiveandmorebedrooms = 4;

            

            
            total = zerobedrooms + onebedrooms+ twobedrooms + threebedrooms
                    + fourbedrooms+ fiveandmorebedrooms;  //the total number of different types of bedrooms 
            
            zeroangle =  360*zerobedrooms/total;  //calculate the angle in pie chart (portion)
            oneangle = 360*onebedrooms/total;
            twoangle = 360*twobedrooms/total;
            threeangle = 360*threebedrooms/total;
            fourangle = 360*fourbedrooms/total;
            fiveandmoreangle = 360*fiveandmorebedrooms/total;
            
            totalangleused = zeroangle+oneangle+twoangle+threeangle+
                    fourangle+fiveandmoreangle;  //total angle used by those portions of the pie chart
            lastwedge = 360-totalangleused;  //the last wedge of the pie chart 
            
             g.setColor(Color.BLACK); 
             g.fillArc(0, 0, 400, 400, 0, zeroangle); // filling the arc
             g.setColor(Color.CYAN);
             g.fillArc(0, 0, 400, 400, zeroangle+0, oneangle); // the next angle size is the total of previous angles
             g.setColor(Color.GREEN);
             g.fillArc(0, 0, 400, 400, oneangle+zeroangle, twoangle);// the next angle size is the total of previous angles
             g.setColor(Color.BLUE);
             g.fillArc(0, 0, 400, 400, twoangle+oneangle+zeroangle, threeangle);// the next angle size is the total of previous angles
             g.setColor(Color.MAGENTA);
             g.fillArc(0, 0, 400, 400, threeangle+twoangle+oneangle+zeroangle,
                     fourangle);// the next angle size is the total of previous angles
             g.setColor(Color.YELLOW);
             g.fillArc(0, 0, 400, 400, fourangle+threeangle+twoangle+oneangle+
                     zeroangle, fiveandmoreangle+lastwedge);// the next angle size is the total of previous angles, and the last wedge is added to the last portion
             
             
           
             
             g.setColor(Color.BLACK);  //the color indication before the string label
             g.fillOval(415, 80, 10, 10);  //color indication location
             g.setColor(Color.CYAN);
             g.fillOval(415, 110, 10, 10);
             g.setColor(Color.GREEN);
             g.fillOval(415, 140, 10, 10);
             g.setColor(Color.BLUE);
             g.fillOval(415, 170, 10, 10);
             g.setColor(Color.MAGENTA);
             g.fillOval(415, 200, 10, 10);
             g.setColor(Color.YELLOW);
             g.fillOval(415, 230, 10, 10);
             
             
             g.setColor(Color.BLACK);
             g.drawString( "3 Bedrooms: "+threebedrooms+"("+(100*threebedrooms/
                     total)+"%)", 430, 180); //draw the labels beside the graph to show the numbers and percentage used
             g.drawString( "4 Bedrooms: "+fourbedrooms+"("+(100*fourbedrooms/
                     total)+"%)", 430, 210 ); 
             g.drawString( "5+ Bedrooms: "+fiveandmorebedrooms+"("+(100*
                     fiveandmorebedrooms/total)+"%)", 430, 240 ); 
             g.drawString( "0 Bedroom: "+zerobedrooms+"("+(100*zerobedrooms/
                     total)+"%)", 430, 90 ); 
             g.drawString( "1 Bedroom: "+onebedrooms+"("+(100*onebedrooms/
                     total)+"%)", 430, 120 ); 
             
             g.drawString( "2 Bedrooms: "+twobedrooms+"("+(100*twobedrooms/
                     total)+"%)", 430, 150 ); 

        }

        
    }

    
    }

     