/*******************************************************************************
 * Project7, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 25, 2019
 * 
 * In this class, the add property information panel is created. There are 
 * various text fields for user to input information. Also, there also includes
 * several drop down menus for users to select options. When user entered all
 * information and click on add button, a window will pop with the message 
 * indicating that the property information has been added. The clear button 
 * clears all information in every entry. Go back button returns to the menu.
*******************************************************************************/
package Assign7;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.JPanel;
import java.awt.event.*;
import javax.swing.*;


public class AddPanel extends JPanel implements ActionListener {
         String[] StateString = { "","Alabama","Alaska","Arizona","Arkansas",""
                 + "California","Colorado","Connecticut","Delaware","Florida",
                 "Georgia","Hawaii","Idaho","Illinois","Indiana","Iowa",
                 "Kansas","Kentucky","Louisiana","Maine","Maryland",
                 "Massachusetts","Michigan","Minnesota","Mississippi","Missouri"
                 ,"Montana","Nebraska","Nevada","New Hampshire","New Jersey",
                 "New Mexico","New York","North Carolina","North Dakota","Ohio",
                 "Oklahoma","Oregon","Pennsylvania","Rhode Island",
                 "South Carolina","South Dakota","Tennessee","Texas","Utah",
                 "Vermont","Virginia","Washington","West Virginia","Wisconsin"
                 ,"Wyoming"}; //50 states
         
         String[] ProptypeString = { "", "Apartment", "Guest Suite", "House", 
             "Condominium", "Bed and Breakfast" }; //type of properties
         String[] RoomtypeString = { "", "Entire House", "Private Room", 
             "Shared Space"}; //room type
         String[] AccommodationString = { "", "1", "2", "3","4","5","6","7","8"
                 ,"9","10"}; //accommodation number
         String[] BedroomsString = { "", "1", "2", "3","4","5","6","7","8",
             "9","10"}; //Bedroom number
         String[] BathroomsString = { "", "1", "2", "3","4","5","6","7","8"
                 ,"9","10"}; //Bathroom number
         
        JLabel PropID = new JLabel("Property ID:");  //instructions 
        JTextField PropIDInput = new JTextField(2); //text field 
        JLabel HostID = new JLabel("Host ID:");   
        JTextField HostIDInput = new JTextField(2);
        JLabel PropName = new JLabel("Property name:");   
        JTextField PropNameInput = new JTextField(2);
        JLabel PropSum = new JLabel("Property summary:");   
        JTextField PropSumInput = new JTextField(2);
        JLabel City = new JLabel("Which city:");   
        JTextField CityInput = new JTextField(2);
        JLabel Zip = new JLabel("Zip code:");   
        JTextField ZipInput = new JTextField(2);
        JLabel Price = new JLabel("Price per night:");   
        JTextField PriceInput = new JTextField(2);
        JLabel Security = new JLabel("Security deposit:"); 
        JTextField SecurityInput = new JTextField(2);
        JLabel Cleaning = new JLabel("Cleaning fee:"); 
        JTextField CleaningInput = new JTextField(2);
         
         
        JLabel InsState = new JLabel("Choose state:"); //instructions
        JLabel InsProptype = new JLabel("Choose property type:");
        JLabel InsRoomtype = new JLabel("Choose room type:");
        JLabel InsAccommodation = new JLabel("Choose accommodations:");
        JLabel InsBed = new JLabel("Choose bedrooms:");
        JLabel InsBath = new JLabel("Choose bathrooms:");
        JLabel InsBlank = new JLabel("");
        
        //JTextField Input = new JTextField(2);
        //JScrollPane Scrolldown = new JScrollPane();
        JButton Add = new JButton("Add");  // add, return and clear buttons
        JButton Exit = new JButton("Go Back");
        JButton Clear = new JButton("Clear");
        
         JComboBox StateChoice = new JComboBox(StateString);  //drop down menus for options
         JComboBox ProptypeChoice = new JComboBox(ProptypeString);
         JComboBox RoomtypeChoice = new JComboBox(RoomtypeString);
         JComboBox AccommodationChoice = new JComboBox(AccommodationString);
         JComboBox BedroomsChoice = new JComboBox(BedroomsString);
         JComboBox BathroomsChoice = new JComboBox(BathroomsString);
        
        
        public AddPanel(){
          
          JPanel bot = new JPanel();// creating a new panel (bottom) only for add, goback, and clear buttons
          setLayout(new GridLayout(8,2)); //setting overall grid layout
          bot.setLayout(new GridLayout(1,3,2,2)); // seetting the new panel (bottom) grid layout
          
          add(PropID);  //adding text filelds and instructions to panel
          add(PropIDInput);
          add(HostID);
          add(HostIDInput);
          add(PropName);
          add(PropNameInput);
          add(PropSum);
          add(PropSumInput);
          add(City);
          add(CityInput);
          add(Zip);
          add(ZipInput);
          add(Price);
          add(PriceInput);
          add(Security);
          add(SecurityInput);
          add(Cleaning);
          add(CleaningInput);
         
          

          add(InsState); // adding drop down menus and instructions to panel
          add(StateChoice);
          add(InsProptype);
          add(ProptypeChoice);
          add(InsRoomtype);
          add(RoomtypeChoice);
          add(InsAccommodation);
          add(AccommodationChoice);
          add(InsBed);
          add(BedroomsChoice);
          add(InsBath);
          add(BathroomsChoice);  
          add(InsBlank);
          
          
          bot.add(Add);  // adding three buttons to the bottom panel
          bot.add(Clear);
          bot.add(Exit);
          
          
         add(bot,BorderLayout.SOUTH); // setting south panel
         //add(bot,BorderLayout.EAST);  
         Add.addActionListener(this);
         Exit.addActionListener(this);
         Clear.addActionListener(this);
                            
        }
    
        public void actionPerformed(ActionEvent e){
       String op = e.getActionCommand(); //get action
       if(op.equals("Clear")){ // when click on clear 
           
           PropIDInput.setText(""); //set all text fields to blank
           HostIDInput.setText("");
           PropNameInput.setText("");
           PropSumInput.setText("");
           CityInput.setText("");
           ZipInput.setText("");
           PriceInput.setText("");
           SecurityInput.setText("");
           CleaningInput.setText("");
           
           StateChoice.setSelectedItem("");//set all drop downs to blank
           ProptypeChoice.setSelectedItem("");
           RoomtypeChoice.setSelectedItem("");
           AccommodationChoice.setSelectedItem("");
           BedroomsChoice.setSelectedItem("");
           BathroomsChoice.setSelectedItem("");
           
           
           
       }
       
       else if(op.equals("Add")){ //when click on add button
      

           JOptionPane.showMessageDialog( null, "I added your property to "
                   + "Airbnb!"); // pop up message window
           PropIDInput.setText(""); //clear all textfields
           HostIDInput.setText("");
           PropNameInput.setText("");
           PropSumInput.setText("");
           CityInput.setText("");
           ZipInput.setText("");
           PriceInput.setText("");
           SecurityInput.setText("");
           CleaningInput.setText("");
           
           StateChoice.setSelectedItem(""); // clear all drop downs
           ProptypeChoice.setSelectedItem("");
           RoomtypeChoice.setSelectedItem("");
           AccommodationChoice.setSelectedItem("");
           BedroomsChoice.setSelectedItem("");
           BathroomsChoice.setSelectedItem("");
           
       }
       
       
       
       else{
           
         MainWindow.mainGUI.setVisible(true); //show main window
         MainWindow.addGUI.setVisible(false);//hide addgui window
       }
} 
}
