/*******************************************************************************
 * Project7, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 25, 2019
 * 
 * In this class, a main method is created and four JFrames are declared, 
 * which are the main panel, property graph panel, add property panel, 
 * and search panel.Also,setDefaultCloseOperation is called four times for each 
 * JFrame object. Window size, location, visibility are specified in the class. 
*******************************************************************************/
package Assign7;

import javax.swing.*;


public class MainWindow {
 public static JFrame mainGUI = new JFrame ("Airbnb Window"); //creating jframes and giving them window names
 public static JFrame searchGUI = new JFrame ("Search Property");
 public static JFrame addGUI = new JFrame ("Add Property");
 public static JFrame graphGUI = new JFrame ("Property Graph");
    
    
    
     public static void main(String[] args) {
         
       MainPanel themainpanel = new MainPanel();  //creating four panels
       GraphPanel thegraphpanel = new GraphPanel();  
       SearchPanel thesearchpanel = new SearchPanel();  
       AddPanel theaddpanel= new AddPanel();  
       
        
        mainGUI.setContentPane(themainpanel); //set content pane, to show content on the panels
        searchGUI.setContentPane(thesearchpanel);
        addGUI.setContentPane(theaddpanel);
        graphGUI.setContentPane(thegraphpanel);      
        

        
        mainGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //exit program when close
        searchGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        addGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        graphGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

       
        MainWindow.mainGUI.setVisible(true);//set main window visible 

        
        mainGUI.setResizable(false); //not resizable 
        mainGUI.setLocation(600,250); //setting location
        mainGUI.setSize(400,300);//setting window size
        
        graphGUI.setResizable(false);//not resizable 
        graphGUI.setLocation(500,50); 
        graphGUI.setSize(600,600);
        
        searchGUI.setResizable(false);//not resizable 
        searchGUI.setLocation(600,250); 
        searchGUI.setSize(500,500);
        
        addGUI.setResizable(false);//not resizable 
        addGUI.setLocation(280,250); 
        addGUI.setSize(1100,300);        
        
      
     }
}
