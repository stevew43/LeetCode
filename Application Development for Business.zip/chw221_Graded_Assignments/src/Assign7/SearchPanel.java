/*******************************************************************************
 * Project7, BIS 335, Business Application Development, Fall 2019
 *
 * Author: Steven Weng
 * Date: November 25, 2019
 * 
 * In this class, the search panel is created. User can search for Airbnb 
 * properties information by typing in the property ID. The property information
 * will show in the Jtextarea, which can also be scrolled. There is also a user
 * input validation for the property ID typed in. There are three buttons: 
 * Search, Go Back and Clear. When user click on Clear, all information will be
 * cleared from the window, including user input.Go back button returns to 
 * the menu.
*******************************************************************************/
package Assign7;

import java.awt.GridLayout;
import javax.swing.JPanel;
import java.awt.event.*;
import javax.swing.*;



public class SearchPanel extends JPanel implements ActionListener {
    
       
        JLabel Instructions = new JLabel("Please type in the property ID:"); //instruction
        JLabel Info = new JLabel("Property information:"); //instruction
        JTextField Input = new JTextField(2); //text field for search input
    
        JButton Search = new JButton("Search"); //search button
        JButton Exit = new JButton("Go Back"); //return button
        JButton Clear = new JButton("Clear"); //clear button
        
  
        JTextArea SearchResult = new JTextArea ("",3,2);    //adding jtextarea
        
        
        JScrollPane Scroller = new JScrollPane( SearchResult ); //adding jscrollpane 

       
       public SearchPanel(){
           
           setLayout(null); //free layout
           setBorder( BorderFactory.createEtchedBorder() ); 
           
          
        //setLayout(new GridLayout(3,1));  //setting layout
        SearchResult.setEditable(false); //not editable 
         add(Instructions); //adding buttons and lables
          Instructions.setBounds(20,20,200,20);
         add(Input);
          Input.setBounds(20,50,120,40);
         add(Search);
          Search.setBounds(150,50,100,40);
         add(Exit);
          Exit.setBounds(360,50,100,40);
         add(Clear);
          Clear.setBounds(255,50,100,40);
         add(Info);
         Info.setBounds(20,100,120,20);
         add(Scroller);
          Scroller.setBounds(20,130,440,300);
         
         Search.addActionListener(this);//adding action listener
         Exit.addActionListener(this);
         Clear.addActionListener(this);
         
       }
    
    public void actionPerformed(ActionEvent e){
        int inputid; //the input property id
    String op = e.getActionCommand(); //get actions

    
    if(op.equals("Search")){
          try {
            String value = Input.getText(); //txt get from jtextfield
            inputid = Integer.parseInt(value); //parse value into integer
         }
         catch (NumberFormatException i) { //catching the error
            
            JOptionPane.showMessageDialog( null, "You must enter a"
                    + " valid integer"); //error message pop up
            return;
         }
          
       if(inputid<=0){
           JOptionPane.showMessageDialog( null, "Must be greater than 0"); //when the input value is under 1, error message
       }   
       else{
          SearchResult.setText("I found your Airbnb property.");//success
       }
          
    }
    
    else if(op.equals("Clear")){   
        Input.setText(""); //clearing input
        SearchResult.setText(""); //clearing search result
    }
    

    
    else{
  
    MainWindow.mainGUI.setVisible(true); //show main gui
    MainWindow.searchGUI.setVisible(false);//hide search window
    }
}    
}